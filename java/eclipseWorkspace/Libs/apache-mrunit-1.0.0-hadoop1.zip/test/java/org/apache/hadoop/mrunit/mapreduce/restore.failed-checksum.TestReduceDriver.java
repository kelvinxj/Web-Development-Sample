ffffff 0%,#e2eff9 100%); /* IE10+ */
        background: linear-gradient(to bottom,  #ffffff 0%,#e2eff9 100%); /* W3C */
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#e2eff9',GradientType=0 ); /* IE6-8 */
        
    }
    
    #TopBar_left {
        line-height: 14px;
        position: absolute;
        padding-top: 30px;
        padding-right: 30px;
        padding-left: 30px;
        text-align: left;
        font: 13px/20px Arial, Helvetica, sans-serif;
        font-weight: bold;
        font-size: 20px;
        color: #333;
    }
    
    #TopBar_right {
        line-height: 12px;
        float: right;
        padding-top: 10px;
        padding-right: 30px;
        text-align: left;
    }
    

    @media print {
        #BreadCrumbs, #Download {
            display: none;
        }
    }
    
     
    @media print {
        #TopBar_right {
            display: none;
        }
    }
    #TopBar_right a {
        font-size: 10px;
        margin: 3px;
        padding: 0;
    }
 
    #BreadCrumbs {
        padding: 15px 5px 0.5em 0;
        font-family: sans-serif; 
        float: right;
    }
    
    #BreadCrumbs a {
        color:#09569d;
    }
    
    #BreadCrumbs a:visited, #BreadCrumbs a:link {
        text-decoration: none;
    }
    
    #BreadCrumbs a:hover, #BreadCrumbs a:active {
        text-decoration: underline;
    }
    
    #PageTitle {
        margin: 0 5px 0.5em 0;
        color: #F90000;
    }
    
    #PageContent{
        margin: 0 5px 0 20px;
    }
    
    .LeftBar_shown {
        width: 13em;
        float: left;
    }
    
    @media print {
        .LeftBar_shown {
            display: none;
        }
    }
    
    .LeftBar_hidden {
        display: none;
    }
    
    #Footer {
        padding-top: 10px;
        padding-left: 10px;
        margin-right: 10px;       
    }
    
    .footertext {
        font-size: 10px;
        font-family: sans-serif; 
        margin-top: 1px;
    }

    .NavBit  {
        padding: 15px 5px 0.5em 0;
        font-family: sans-serif; 
    }
    
    @media print {
        .NavBit {
            display: none;
        }
    }
    
    #TagNotes {
        text-align: right;        
    }
    
    @media print {
        #TagNotes a:visited, #TagNotes a:link {
            color: #35556B;
            text-decoration: none;
        }
    }
    
    #Contents a, .NavBit a, #TagNotes a {
        color:#09569d;
    }
    
    #TagNotes a:visited, #TagNotes a:link,
    #Contents a:visited, #Contents a:link,
    .NavBit a:visited, .NavBit a:link {
        text-decoration: none;
    }
    
    #TagNotes a:hover, #TagNotes a:active,   
    #Contents a:hover, #Contents a:active,   
    .NavBit a:hover, .NavBit a:active {  
        text-decoration: underline;
    }
    
    #Contents {
        float: left;
        font-family: sans-serif; 
    }
    @media print {
        #Contents {
            display: none;
        }
    }
    @media screen {
        div.PrintHeaders {
            display: none;
        }
    }
    .linkLESSON, .nolinkLESSON {
        margin-left: 0.5em;
        text-indent: -0.5em;
    }
    .linkAHEAD, .nolinkAHEAD, .linkQUESTIONS, .nolinkQUESTIONS   {
        margin-left: 1.5em; 
        text-indent: -0.5em
    }
    .linkBHEAD, .nolinkBHEAD   {
        margin-left: 2.5em;
        text-indent: -0.5em
    }
    .linkCHEAD, .nolinkCHEAD   {
        margin-left: 3.5em;
        text-indent: -0.5em
    }
    .nolinkLESSON, .nolinkAHEAD, .nolinkBHEAD, .nolinkCHEAD,
    .nolinkQUESTIONS {
        font-weight: bold;
        color: #333;
		
		
    }
    .MainFlow_indented {
        margin-right: 10px;
        margin-left: 15em;
        margin-bottom: 2em;

    }
    .MainFlow_wide {
	
        margin-right: 10px;
        margin-left: 10px;
        margin-bottom: 2em;

    }
    @media print {
        .MainFlow_indented, .MainFlow_wide {
            padding-top: 0;
            margin-top: 10px;
            margin-right: 10px;
            margin-left: 0;
        }
    }
    h1, h2, h3, h4, h5 {
        color/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.mrunit.mapreduce;

import static org.apache.hadoop.mrunit.ExtendedAssert.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.reduce.IntSumReducer;
import org.apache.hadoop.mapreduce.lib.reduce.LongSumReducer;
import org.apache.hadoop.mrunit.ExpectedSuppliedException;
import org.apache.hadoop.mrunit.types.Pair;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

public class TestReduceDriver {

  private static final int IN_A = 4;
  private static final int IN_B = 6;
  private static final int OUT_VAL = 10;
  private static final int INCORRECT_OUT = 12;
  @Rule
  public final ExpectedSuppliedException thrown = ExpectedSuppliedException
      .none();
  private Reducer<Text, LongWritable, Text, LongWritable> reducer;
  private ReduceDriver<Text, LongWritable, Text, LongWritable> driver;

  @Before
  public void setUp() throws Exception {
    reducer = new LongSumReducer<Text>();
    driver = ReduceDriver.newReduceDriver(reducer);
  }

  @Test
  public void testRun() throws IOException {
    final List<Pair<Text, LongWritable>> out = driver
        .withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B)).run();

    final List<Pair<Text, LongWritable>> expected = new ArrayList<Pair<Text, LongWritable>>();
    expected.add(new Pair<Text, LongWritable>(new Text("foo"),
        new LongWritable(OUT_VAL)));

    assertListEquals(out, expected);

  }

  @Test
  public void testTestRun1() throws IOException {
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL)).runTest();
  }

  @Test
  public void testTestRun2() throws IOException {
    thrown
        .expectAssertionErrorMessage("2 Error(s): (Missing expected output (bar, 10) at position 0., "
            + "Received unexpected output (foo, 10) at position 0.)");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("bar"), new LongWritable(OUT_VAL)).runTest(true);
  }

  @Test
  public void testTestRun2OrderInsensitive() throws IOException {
    thrown
        .expectAssertionErrorMessage("2 Error(s): (Missing expected output (bar, 10), "
            + "Received unexpected output (foo, 10))");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWri: #333;
        
    }

    h1 {
        font-weight: bold;
        font-size: 20px;
    }

    h2 {
        font-weight: bold;
        font-size: 17px;
    }

    h3 {
        font-weight: bold;
        font-size: 14px;
    }

    h4 {
        font-size: 15px;
    }

    h5 {
        font-size: 12px;
    }


    #ToggleLeft {
        display: none;
    }
    
    .note {
        margin: 0 30px 0px 30px;
    }
    
    .codeblock {
        margin: 0 30px 0px 30px;
		font-size:12px;
		font-family:Monaco,Courier,"Courier New";
    }
    
    .tocli {
        list-style-type:none;
    }

    .betadraft {
        color: red;
    }

</style>
<script type="text/javascript">
/* <![CDATA[ */
    function leftBar() {
        var nameq = 'tutorial_showLeftBar='
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookieString = cookies[i];
            while (cookieString.charAt(0) == ' ') {
                cookieString = cookieString.substring(1, cookieString.length);
            }
            if (cookieString.indexOf(nameq) == 0) {
                cookieValue =  cookieString.substring(nameq.length,
                        cookieString.length);
                return cookieValue == 'yes';
            }
        }
        return true;
    }

    function showLeft(b) {
        var contents = document.getElementById("LeftBar");
        var main = document.getElementById("MainFlow");
        var toggle = document.getElementById("ToggleLeft");
        if (b) {
            contents.className = "LeftBar_shown";
            main.className = "MainFlow_indented";
            toggle.innerHTML = "Hide TOC";
            document.cookie = 'tutorial_showLeftBar=yes; path=/';
        } else {
            contents.className = "LeftBar_hidden";
            main.className = "MainFlow_wide";
            toggle.innerHTML = "Show the TOC";
            document.cookie = 'tutorial_showLeftBar=no; path=/';
        }
    }

    function toggleLeft() {
        showLeft(document.getElementById("LeftBar").className ==
                "LeftBar_hidden");
        document.getElementById("ToggleLeft").blur();
    }

    function load() {
        showLeft(leftBar());
        document.getElementById("ToggleLeft").style.display="inline";
    }

    function showCode(displayCodePage, codePath) {
        var codePathEls = codePath.split("/");
        var currDocPathEls = location.href.split("/");
        //alert ("codePathEls = " + codePathEls + "\n" + "currDocPathEls = " + currDocPathEls);
        currDocPathEls.pop(); // remove file name at the end
        while (codePathEls.length > 0) {
            if (codePathEls[0] == "..") {
                codePathEls.shift();
                currDocPathEls.pop();
            } else {
                break;
            }
        }
        var fullCodePath = currDocPathEls.join("/") + "/" + codePathEls.join("/");
        //alert ("fullCodePath = " + fullCodePath );
        if (codePath.indexOf(".java") != -1 || codePath.indexOf(".jnlp") != -1) {
            window.location.href = displayCodePage + "?code=" + encodeURI(fullCodePath);
        } else {
            window.location.href = fullCodePath;
        }
    }
/* ]]> */    
</script>


    </head>
<body onload="load()">
    <noscript>
        A browser with JavaScript enabled is required for this page to operate properly.
    </noscript>
        <!-- header -->
    <div class="header-container">
        <div class="bookwrapper  clearfix">       
            <div id="brandProdName">
                <div id="logocover"></div>
                <div id="productName" >Documentation</div>
            </div> 
            <br class="clearfloat" />
        </div>
    </div>
    
    <div id="TopBar">
        <div id="TopBar_tr">
            <div id="TopBar_tl">
                <div id="TopBar_br"> <div id="TopBar_bl"> 
                    <div id="TopBar_left">The Java&trade; Tutorials</div>
                        <div id="TopBar_right"> 
                            <!--
                            <a href="URL" target="_table(IN_B))
        .withOutput(new Text("bar"), new LongWritable(OUT_VAL)).runTest(false);
  }

  @Test
  public void testTestRun3() throws IOException {
    thrown
        .expectAssertionErrorMessage("2 Error(s): (Missing expected output (foo, 12) at position 0., "
            + "Received unexpected output (foo, 10) at position 0.)");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(INCORRECT_OUT))
        .runTest(true);
  }

  @Test
  public void testTestRun3OrderInsensitive() throws IOException {
    thrown
        .expectAssertionErrorMessage("2 Error(s): (Missing expected output (foo, 12), "
            + "Received unexpected output (foo, 10))");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(INCORRECT_OUT))
        .runTest(false);
  }

  @Test
  public void testTestRun4() throws IOException {
    thrown
        .expectAssertionErrorMessage("2 Error(s): (Missing expected output (foo, 4) at position 0., "
            + "Received unexpected output (foo, 10) at position 0.)");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(IN_A)).runTest(true);
  }

  @Test
  public void testTestRun4OrderInsensitive() throws IOException {
    thrown
        .expectAssertionErrorMessage("2 Error(s): (Missing expected output (foo, 4), "
            + "Received unexpected output (foo, 10))");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(IN_A)).runTest(false);
  }

  @Test
  public void testTestRun5() throws IOException {
    thrown
        .expectAssertionErrorMessage("3 Error(s): (Missing expected output (foo, 6) at position 1., "
            + "Missing expected output (foo, 4) at position 0., "
            + "Received unexpected output (foo, 10) at position 0.)");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(IN_A))
        .withOutput(new Text("foo"), new LongWritable(IN_B)).runTest(true);
  }

  @Test
  public void testTestRun5OrderInsensitive() throws IOException {
    thrown
        .expectAssertionErrorMessage("3 Error(s): (Missing expected output (foo, 6), "
            + "Missing expected output (foo, 4), "
            + "Received unexpected output (foo, 10))");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(IN_A))
        .withOutput(new Text("foo"), new LongWritable(IN_B)).runTest(false);
  }

  @Test
  public void testTestRun6() throws IOException {
    thrown
        .expectAssertionErrorMessage("1 Error(s): (Missing expected output (foo, 10) at position 1.)");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL)).runTest(true);
  }

  @Test
  public void testTestRun6OrderInsensitive() throws IOException {
    thrown
        .expectAssertionErrorMessage("1 Error(s): (Missing expected output (foo, 10))");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL)).runTest(false);
  }

  @Test
  public void testTestRun7() throws IOException {
    thrown
        .expectAssertionErrorMessage("2 Error(s): (Missing expected output (bar, 10) blank">External Link</a><br/>
                            --> 
                            <a href="javascript:toggleLeft()" id="ToggleLeft">Hide TOC</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="LeftBar" class="LeftBar_shown">
        <div id="Contents">
            <div class="linkLESSON"><a href="index.html">Working with Text</a></div>
<div class="linkAHEAD"><a href="charintro.html">Checking Character Properties</a></div>
<div class="linkAHEAD"><a href="collationintro.html">Comparing Strings</a></div>
<div class="linkBHEAD"><a href="locale.html">Performing Locale-Independent Comparisons</a></div>
<div class="linkBHEAD"><a href="rule.html">Customizing Collation Rules</a></div>
<div class="linkBHEAD"><a href="perform.html">Improving Collation Performance</a></div>
<div class="linkAHEAD"><a href="unicode.html">Unicode</a></div>
<div class="linkBHEAD"><a href="terminology.html">Terminology</a></div>
<div class="linkBHEAD"><a href="supplementaryChars.html">Supplementary Characters as Surrogates</a></div>
<div class="linkBHEAD"><a href="characterClass.html">Character and String APIs</a></div>
<div class="linkBHEAD"><a href="usage.html">Sample Usage</a></div>
<div class="nolinkBHEAD">Design Considerations</div>
<div class="linkBHEAD"><a href="info.html">More Information</a></div>
<div class="linkAHEAD"><a href="boundaryintro.html">Detecting Text Boundaries</a></div>
<div class="linkBHEAD"><a href="about.html">About the BreakIterator Class</a></div>
<div class="linkBHEAD"><a href="char.html">Character Boundaries</a></div>
<div class="linkBHEAD"><a href="word.html">Word Boundaries</a></div>
<div class="linkBHEAD"><a href="sentence.html">Sentence Boundaries</a></div>
<div class="linkBHEAD"><a href="line.html">Line Boundaries</a></div>
<div class="linkAHEAD"><a href="shapedDigits.html">Converting Latin Digits to Other Unicode Digits</a></div>
<div class="linkAHEAD"><a href="convertintro.html">Converting Non-Unicode Text</a></div>
<div class="linkBHEAD"><a href="string.html">Byte Encodings and Strings</a></div>
<div class="linkBHEAD"><a href="stream.html">Character and Byte Streams</a></div>
<div class="linkAHEAD"><a href="normalizerapi.html">Normalizing Text</a></div>
<div class="linkAHEAD"><a href="bidi.html">Working with Bidirectional Text with the JTextComponent Class</a></div>
</div>
    </div>
    <div id="MainFlow" class="MainFlow_indented">
    <div class="PrintHeaders">
        <b>Trail:</b> Internationalization
        <br /><b>Lesson:</b> Working with Text
        <br /><b>Section:</b> Unicode
    </div>
            <div id="BreadCrumbs">
                <a href="../../index.html" target="_top">Home Page</a>
                &gt;
                <a href="../index.html" target="_top">Internationalization</a>
                &gt;
                <a href="index.html" target="_top">Working with Text</a>
            </div>
            <div class="NavBit">
                <a target="_top" href="usage.html">&laquo;&nbsp;Previous</a>&nbsp;&bull;&nbsp;<a target="_top" href="../TOC.html">Trail</a>&nbsp;&bull;&nbsp;<a target="_top" href="info.html">Next&nbsp;&raquo;</a>
            </div>
            <div class="Banner"><p style="background-color: rgb(247, 248, 249); border-width: 1px; padding: 10px; font-style: italic; border-style: solid; border-color: rgb(64, 74, 91);">The Java Tutorials have been written for JDK 8. Examples and practices described in this page don't take advantage of improvements introduced in later releases.</p></div>
            <div id="PageTitle"><h1>Design Considerations</h1></div>
            <div id="PageContent">

<!-- Design considerations -->
<p>To write code that works seamlessly for any language using any script, there are a few things to keep in mind.</p>

<table border="1" summary="design considerations to write easily localizable code">
<tr>
<th>Consideration</th>
<th>Reason</th>
</tr>
<tr>
<td>Avoid methods that use the <code>char</code> data type.</td>
<td>Avoid using the <code>char</code> primitat position 0., "
            + "Matched expected output (foo, 10) but at incorrect position 0 (expected position 1))");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("bar"), new LongWritable(OUT_VAL))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL)).runTest(true);
  }

  @Test
  public void testTestRun7OrderInsensitive() throws IOException {
    thrown
        .expectAssertionErrorMessage("1 Error(s): (Missing expected output (bar, 10))");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("bar"), new LongWritable(OUT_VAL))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL)).runTest(false);
  }

  @Test
  public void testTestRun8() throws IOException {
    thrown
        .expectAssertionErrorMessage("1 Error(s): (Missing expected output (bar, 10) at position 1.)");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL))
        .withOutput(new Text("bar"), new LongWritable(OUT_VAL)).runTest(true);
  }

  @Test
  public void testTestRun8OrderInsensitive() throws IOException {
    thrown
        .expectAssertionErrorMessage("1 Error(s): (Missing expected output (bar, 10))");
    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(IN_A))
        .withInputValue(new LongWritable(IN_B))
        .withOutput(new Text("foo"), new LongWritable(OUT_VAL))
        .withOutput(new Text("bar"), new LongWritable(OUT_VAL)).runTest(false);
  }

  @Test
  public void testAddAll() throws IOException {
    final List<LongWritable> vals = new ArrayList<LongWritable>();
    vals.add(new LongWritable(IN_A));
    vals.add(new LongWritable(IN_B));

    final List<Pair<Text, List<LongWritable>>> inputs = new ArrayList<Pair<Text, List<LongWritable>>>();
    inputs.add(new Pair<Text, List<LongWritable>>(new Text("foo"), vals));

    final List<Pair<Text, LongWritable>> expected = new ArrayList<Pair<Text, LongWritable>>();
    expected.add(new Pair<Text, LongWritable>(new Text("foo"),
        new LongWritable(OUT_VAL)));

    driver.withAll(inputs).withAllOutput(expected).runTest();
  }
  
  @Test
  public void testNoInput() throws IOException {
    driver = ReduceDriver.newReduceDriver();
    thrown.expectMessage(IllegalStateException.class, "No input was provided");
    driver.runTest();
  }

  /**
   * Reducer that counts its values twice; the second iteration according to
   * mapreduce semantics should be empty.
   */
  private static class DoubleIterReducer<K, V> extends
      Reducer<K, V, K, LongWritable> {
    @Override
    @SuppressWarnings("unused")
    public void reduce(final K key, final Iterable<V> values, final Context c)
        throws IOException, InterruptedException {
      long count = 0;

      for (final V val : values) {
        count++;
      }

      // This time around, iteration should yield no values.
      for (final V val : values) {
        count++;
      }
      c.write(key, new LongWritable(count));
    }
  }

  @Test
  public void testDoubleIteration() throws IOException {
    reducer = new DoubleIterReducer<Text, LongWritable>();
    driver = ReduceDriver.newReduceDriver(reducer);

    driver.withInputKey(new Text("foo")).withInputValue(new LongWritable(1))
        .withInputValue(new LongWritable(1))
        .withInputValue(new LongWritable(1))
        .withInputValue(new LongWritable(1))
        .withOutput(new Text("foo"), new LongWritable(4)).runTest();
  }

  @Test
  public void testConfiguration() throws IOException {
    final Configuration conf = new Configuration();
    conf.set("TestKey", "TestValue");
    final ReduceDriver<NullWritable, NullWritable, NullWritable, NullWritable> confDriver = ReduceDriver
        .newReduceDriver();
    final ConfigurationReducer<NullWritable, NullWritable, NullWritable, NullWrita