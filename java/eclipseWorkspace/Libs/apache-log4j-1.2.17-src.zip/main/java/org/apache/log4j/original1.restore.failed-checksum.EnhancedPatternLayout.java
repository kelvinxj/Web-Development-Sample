: #333;
        
    }

    h1 {
        font-weight: bold;
        font-size: 20px;
    }

    h2 {
        font-weight: bold;
        font-size: 17px;
    }

    h3 {
        font-weight: bold;
        font-size: 14px;
    }

    h4 {
        font-size: 15px;
    }

    h5 {
        font-size: 12px;
    }


    #ToggleLeft {
        display: none;
    }
    
    .note {
        margin: 0 30px 0px 30px;
    }
    
    .codeblock {
        margin: 0 30px 0px 30px;
		font-size:12px;
		font-family:Monaco,Courier,"Courier New";
    }
    
    .tocli {
        list-style-type:none;
    }

    .betadraft {
        color: red;
    }

</style>
<script type="text/javascript">
/* <![CDATA[ */
    function leftBar() {
        var nameq = 'tutorial_showLeftBar='
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookieString = cookies[i];
            while (cookieString.charAt(0) == ' ') {
                cookieString = cookieString.substring(1, cookieString.length);
            }
            if (cookieString.indexOf(nameq) == 0) {
                cookieValue =  cookieString.substring(nameq.length,
                        cookieString.length);
                return cookieValue == 'yes';
            }
        }
        return true;
    }

    function showLeft(b) {
        var contents = document.getElementById("LeftBar");
        var main = document.getElementById("MainFlow");
        var toggle = document.getElementById("ToggleLeft");
        if (b) {
            contents.className = "LeftBar_shown";
            main.className = "MainFlow_indented";
            toggle.innerHTML = "Hide TOC";
            document.cookie = 'tutorial_showLeftBar=yes; path=/';
        } else {
            contents.className = "LeftBar_hidden";
            main.className = "MainFlow_wide";
            toggle.innerHTML = "Show the TOC";
            document.cookie = 'tutorial_showLeftBar=no; path=/';
        }
    }

    function toggleLeft() {
        showLeft(document.getElementById("LeftBar").className ==
                "LeftBar_hidden");
        document.getElementById("ToggleLeft").blur();
    }

    function load() {
        showLeft(leftBar());
        document.getElementById("ToggleLeft").style.display="inline";
    }

    function showCode(displayCodePage, codePath) {
        var codePathEls = codePath.split("/");
        var currDocPathEls = location.href.split("/");
        //alert ("codePathEls = " + codePathEls + "\n" + "currDocPathEls = " + currDocPathEls);
        currDocPathEls.pop(); // remove file name at the end
        while (codePathEls.length > 0) {
            if (codePathEls[0] == "..") {
                codePathEls.shift();
                currDocPathEls.pop();
            } else {
                break;
            }
        }
        var fullCodePath = currDocPathEls.join("/") + "/" + codePathEls.join("/");
        //alert ("fullCodePath = " + fullCodePath );
        if (codePath.indexOf(".java") != -1 || codePath.indexOf(".jnlp") != -1) {
            window.location.href = displayCodePage + "?code=" + encodeURI(fullCodePath);
        } else {
            window.location.href = fullCodePath;
        }
    }
/* ]]> */    
</script>


    </head>
<body onload="load()">
    <noscript>
        A browser with JavaScript enabled is required for this page to operate properly.
    </noscript>
        <!-- header -->
    <div class="header-container">
        <div class="bookwrapper  clearfix">       
            <div id="brandProdName">
                <div id="logocover"></div>
                <div id="productName" >Documentation</div>
            </div> 
            <br class="clearfloat" />
        </div>
    </div>
    
    <div id="TopBar">
        <div id="TopBar_tr">
            <div id="TopBar_tl">
                <div id="TopBar_br"> <div id="TopBar_bl"> 
                    <div id="TopBar_left">The Java&trade; Tutorials</div>
                        <div id="TopBar_right"> 
                            <!--
                            <a href="URL" target="_/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.log4j;

import org.apache.log4j.helpers.OptionConverter;
import org.apache.log4j.helpers.PatternConverter;
import org.apache.log4j.pattern.BridgePatternConverter;
import org.apache.log4j.spi.LoggingEvent;


// Contributors:   Nelson Minar <nelson@monkey.org>
//                 Anders Kristensen <akristensen@dynamicsoft.com>

/**
 * This class is an enhanced version of org.apache.log4j.PatternLayout
 * which was originally developed as part of the abandoned log4j 1.3
 * effort and has been available in the extras companion.
 * This pattern layout should be used in preference to
 * org.apache.log4j.PatternLayout except when compatibility
 * where PatternLayout has been extended either through subclassing
 * or alternative pattern parsers.
 *
 *
  * <p>A flexible layout configurable with pattern string. The goal of this class
  * is to {@link #format format} a {@link LoggingEvent} and return the results
  * in a {@link StringBuffer}. The format of the result depends on the
  * <em>conversion pattern</em>.
  * <p>
  *
  * <p>The conversion pattern is closely related to the conversion
  * pattern of the printf function in C. A conversion pattern is
  * composed of literal text and format control expressions called
  * <em>conversion specifiers</em>.
  *
  * <p><i>Note that you are free to insert any literal text within the
  * conversion pattern.</i>
  * </p>

   <p>Each conversion specifier starts with a percent sign (%) and is
   followed by optional <em>format modifiers</em> and a <em>conversion
   character</em>. The conversion character specifies the type of
   data, e.g. category, priority, date, thread name. The format
   modifiers control such things as field width, padding, left and
   right justification. The following is a simple example.

   <p>Let the conversion pattern be <b>"%-5p [%t]: %m%n"</b> and assume
   that the log4j environment was set to use a EnhancedPatternLayout. Then the
   statements
   <pre>
   Category root = Category.getRoot();
   root.debug("Message 1");
   root.warn("Message 2");
   </pre>
   would yield the output
   <pre>
   DEBUG [main]: Message 1
   WARN  [main]: Message 2
   </pre>

   <p>Note that there is no explicit separator between text and
   conversion specifiers. The pattern parser knows when it has reached
   the end of a conversion specifier when it reads a conversion
   character. In the example above the conversion specifier
   <b>%-5p</b> means the priority of the logging event should be left
   justified to a width of five characters.

   The recognized conversion characters are

   <p>
   <table border="1" CELLPADDING="8">
   <th>Conversion Character</th>
   <th>Effect</th>

   <tr>
     <td align=center><b>c</b></td>

     <td>Used to output the category of the logging event. The
     category conversion specifier can be optionally followed by
     NameAbbreviator pattern.

     <p>For example, for the category name "alpha.beta.gamma" the pattern
     <b>%c{2}</b> will output the last two elements ("beta.gamma"),
     <b>%c{-2}</b> will remove two elements leaving "gamma",
     <b>%c{1.}</b> will output "a.b.gamma".

     </td>
   </tr>

   <tr>
     <td align=center><b>C</b></td>

     <td>Used to output the fully qualified class name of the caller
     issuing thblank">External Link</a><br/>
                            --> 
                            <a href="javascript:toggleLeft()" id="ToggleLeft">Hide TOC</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="LeftBar" class="LeftBar_shown">
        <div id="Contents">
            <div class="linkLESSON"><a href="index.html">Drag and Drop and Data Transfer</a></div>
<div class="linkAHEAD"><a href="intro.html">Introduction to DnD</a></div>
<div class="linkAHEAD"><a href="defaultsupport.html">Default DnD Support</a></div>
<div class="linkBHEAD"><a href="basicdemo.html">Demo - BasicDnD</a></div>
<div class="linkAHEAD"><a href="transferhandler.html">TransferHandler Class</a></div>
<div class="linkBHEAD"><a href="export.html">Export Methods</a></div>
<div class="linkBHEAD"><a href="import.html">Import Methods</a></div>
<div class="linkAHEAD"><a href="transfersupport.html">TransferSupport Class</a></div>
<div class="linkAHEAD"><a href="dropmodes.html">Setting the Drop Mode</a></div>
<div class="linkBHEAD"><a href="dropmodedemo.html">Demo - DropDemo</a></div>
<div class="linkAHEAD"><a href="dropaction.html">Choosing the Drop Action</a></div>
<div class="linkBHEAD"><a href="dropactiondemo.html">Demo - ChooseDropAction</a></div>
<div class="linkAHEAD"><a href="showdroploc.html">Showing the Drop Location</a></div>
<div class="linkAHEAD"><a href="locsensitivedrop.html">Location Sensitive Drop</a></div>
<div class="linkBHEAD"><a href="locsensitivedemo.html">Demo - LocationSensitiveDemo</a></div>
<div class="linkAHEAD"><a href="emptytable.html">Empty Table Drop</a></div>
<div class="linkAHEAD"><a href="droplocation.html">Drop Location Rendering</a></div>
<div class="linkAHEAD"><a href="toplevel.html">Top-Level Drop</a></div>
<div class="nolinkAHEAD">Adding Cut, Copy and Paste (CCP)</div>
<div class="linkAHEAD"><a href="textpaste.html">CCP in a Text Component</a></div>
<div class="linkAHEAD"><a href="listpaste.html">CCP in a non-Text Component</a></div>
<div class="linkAHEAD"><a href="dataflavor.html">Using and Creating a DataFlavor</a></div>
<div class="linkAHEAD"><a href="together.html">Putting it All Together - DnD and CCP</a></div>
<div class="linkAHEAD"><a href="problems.html">Solving Common Data Transfer Problems</a></div>
</div>
    </div>
    <div id="MainFlow" class="MainFlow_indented">
    <div class="PrintHeaders">
        <b>Trail:</b> Creating a GUI With JFC/Swing
        <br /><b>Lesson:</b> Drag and Drop and Data Transfer
    </div>
            <div id="BreadCrumbs">
                <a href="../../index.html" target="_top">Home Page</a>
                &gt;
                <a href="../index.html" target="_top">Creating a GUI With JFC/Swing</a>
                &gt;
                <a href="index.html" target="_top">Drag and Drop and Data Transfer</a>
            </div>
            <div class="NavBit">
                <a target="_top" href="toplevel.html">&laquo;&nbsp;Previous</a>&nbsp;&bull;&nbsp;<a target="_top" href="../TOC.html">Trail</a>&nbsp;&bull;&nbsp;<a target="_top" href="textpaste.html">Next&nbsp;&raquo;</a>
            </div>
            <div class="Banner"><p style="background-color: rgb(247, 248, 249); border-width: 1px; padding: 10px; font-style: italic; border-style: solid; border-color: rgb(64, 74, 91);">The Java Tutorials have been written for JDK 8. Examples and practices described in this page don't take advantage of improvements introduced in later releases.</p></div>
            <div id="PageTitle"><h1>Adding Cut, Copy and Paste (CCP)</h1></div>
            <div id="PageContent">

<!-- Adding Cut, Copy and Paste -->
<p>So far our discussion has centered mostly around drag and drop support. However, it is an easy matter to hook up cut or copy or paste (ccp) to a transfer handler. This requires the following steps:</p>
<ul>
<li>Ensure a transfer handler is installed on the component.</li>
<li>Create a manner by which the <code>TransferHandler</code>&#39;s ccp support can be invoked. Typically this involves adding bindie logging request. This conversion specifier
     can be optionally followed by <em>precision specifier</em>, that
     is a decimal constant in brackets.

     <td>Used to output the category of the logging event. The
     category conversion specifier can be optionally followed by
     NameAbbreviator pattern.

     <p>For example, for the category name "alpha.beta.gamma" the pattern
     <b>%c{2}</b> will output the last two elements ("beta.gamma"),
     <b>%c{-2}</b> will remove two elements leaving "gamma",
     <b>%c{1.}</b> will output "a.b.gamma".

     <p><b>WARNING</b> Generating the caller class information is
     slow. Thus, its use should be avoided unless execution speed is
     not an issue.

     </td>
     </tr>

   <tr> <td align=center><b>d</b></td> <td>Used to output the date of
         the logging event. The date conversion specifier may be
         followed by a set of braces containing a
         date and time pattern strings {@link java.text.SimpleDateFormat},
         <em>ABSOLUTE</em>, <em>DATE</em> or <em>ISO8601</em>
          and a set of braces containing a time zone id per 
          {@link java.util.TimeZone#getTimeZone(String)}.           
          For example, <b>%d{HH:mm:ss,SSS}</b>,
         <b>%d{dd&nbsp;MMM&nbsp;yyyy&nbsp;HH:mm:ss,SSS}</b>,
         <b>%d{DATE}</b> or <b>%d{HH:mm:ss}{GMT+0}</b>. If no date format specifier is given then
         ISO8601 format is assumed.  
     </td>
   </tr>

   <tr>
   <td align=center><b>F</b></td>

   <td>Used to output the file name where the logging request was
   issued.

   <p><b>WARNING</b> Generating caller location information is
   extremely slow and should be avoided unless execution speed
   is not an issue.

   </tr>

   <tr>
   <td align=center><b>l</b></td>

     <td>Used to output location information of the caller which generated
     the logging event.

     <p>The location information depends on the JVM implementation but
     usually consists of the fully qualified name of the calling
     method followed by the callers source the file name and line
     number between parentheses.

     <p>The location information can be very useful. However, its
     generation is <em>extremely</em> slow and should be avoided
     unless execution speed is not an issue.

     </td>
   </tr>

   <tr>
   <td align=center><b>L</b></td>

   <td>Used to output the line number from where the logging request
   was issued.

   <p><b>WARNING</b> Generating caller location information is
   extremely slow and should be avoided unless execution speed
   is not an issue.

   </tr>


   <tr>
     <td align=center><b>m</b></td>
     <td>Used to output the application supplied message associated with
     the logging event.</td>
   </tr>

   <tr>
   <td align=center><b>M</b></td>

   <td>Used to output the method name where the logging request was
   issued.

   <p><b>WARNING</b> Generating caller location information is
   extremely slow and should be avoided unless execution speed
   is not an issue.

   </tr>

   <tr>
     <td align=center><b>n</b></td>

     <td>Outputs the platform dependent line separator character or
     characters.

     <p>This conversion character offers practically the same
     performance as using non-portable line separator strings such as
     "\n", or "\r\n". Thus, it is the preferred way of specifying a
     line separator.


   </tr>

   <tr>
     <td align=center><b>p</b></td>
     <td>Used to output the priority of the logging event.</td>
   </tr>

   <tr>

     <td align=center><b>r</b></td>

     <td>Used to output the number of milliseconds elapsed since the construction 
     of the layout until the creation of the logging event.</td>
   </tr>


   <tr>
     <td align=center><b>t</b></td>

     <td>Used to output the name of the thread that generated the
     logging event.</td>

   </tr>

   <tr>

     <td align=center><b>x</b></td>

     <td>Used to output the NDC (nested diagnostic context) associated
     with the thread that generated the logging event.
     </td>
   </tr>


   <tr>
     <td align=center><bngs to the input and action maps to have the <code>TransferHandler</code>&#39;s ccp actions invoked in response to particular keystrokes.</li>
<li>Create ccp menu items and/or buttons. (This step is optional but recommended.) This is easy to do with text components but requires a bit more work with other components, since you need logic to determine which component to fire the action on. See 
<a class="TutorialLink" target="_top" href="listpaste.html">CCP in a non-Text Component</a> for more information.</li>
<li>Decide where you want to perform the paste. Perhaps above or below the current selection. Install the logic in the <code>importData</code> method.</li>
</ul>
<p>Next we look at a cut and paste example that feature a text component.</p>


        </div>
        <div class="NavBit">
            <a target="_top" href="toplevel.html">&laquo; Previous</a>
            &bull;
            <a target="_top" href="../TOC.html">Trail</a>
            &bull;
            <a target="_top" href="textpaste.html">Next &raquo;</a>
        </div>
    </div>
    
<hr class="clearfloat"/>

<div id="Footer">

<p class="footertext">
<a href="http://www.oracle.com/corporate/index.html">About Oracle</a> | 
<a href="http://www.oracle.com/us/corporate/contact/index.html">Contact Us</a> |
<a href="http://www.oracle.com/us/legal/index.html">Legal Notices</a> | 
<a href="http://www.oracle.com/us/legal/terms/index.html">Terms of Use</a> |
<a href="http://www.oracle.com/us/legal/privacy/index.html">Your Privacy Rights</a></p>

<p class="footertext"><a href="http://www.oracle.com/pls/topic/lookup?ctx=cpyr&id=en-US">
Copyright &copy; 1995, 2017 Oracle and/or its affiliates. All rights reserved.</a></p>
       
</div>    
    <div class="PrintHeaders">
        <b>Previous page:</b> Top-Level Drop
        <br /><b>Next page:</b> CCP in a Text Component
    </div>
</body>
</html> 
