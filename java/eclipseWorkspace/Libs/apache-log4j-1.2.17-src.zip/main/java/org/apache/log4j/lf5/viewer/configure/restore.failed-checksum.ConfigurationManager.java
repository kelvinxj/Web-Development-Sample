<html dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<style type="text/css">
body { margin: 0 0 0 0; padding:0 0 0 0 }
td,div { font-family:Arial;font-size:12pt;vertical-align:top }
/* Copyright IBM Corp. 2015  All Rights Reserved.                    */
body { margin: 0 0 0 0; padding:0 0 0 0; overflow:hidden; background-color:#fafafa; }
.grayBackground { background-color:#f6f6f6; }
.transcript { background-color:#d2d2d2;}
.messageBlock {padding-left:10px; padding-right:10px;padding-top:0}
.expansion{height:10px;width:100%;overflow:hidden;}
.expansionx{height:10px;overflow:hidden;}
.line{height:1px;background-color:#cccccc;overflow:hidden;}
.message { padding-left:0px; padding-right:65px;margin-left:0px; word-wrap:break-word; white-space:-moz-pre-wrap; _white-space:pre; white-space:pre-wrap;}
.messageCont { padding-left:20px; margin-left:95px; word-wrap:break-word; white-space:-moz-pre-wrap; _white-space:pre;white-space:pre-wrap;}
.other { font-size:11px;color:#1970b0;vertical-align:top;font-weight:bold;font-style:normal;float:left; width:95px; white-space:nowrap; }
.myself { font-size:11px;color:#222222;font-style:normal;font-weight:bold;font-style:normal;float:left; width:95px; white-space:nowrap; }
.otherCont { font-size:8px;text-align:right; color:#1970b0;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.myselfCont { font-size:8px;text-align:right; color:#222222;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.system { font-size:11px; word-wrap:break-word;color:#d13f08;font-style:normal;font-weight:normal; white-space:-moz-pre-wrap; _white-space:pre;white-space:pre-wrap; }
.showTimestamp { padding-left:20px;font-size:11px; float:right; color:#999999;font-style:normal;font-weight:normal; }
.other1 { font-size:11px; color:#ba006e;vertical-align:top;font-weight:bold;font-style:normal;float:left; width:95px; }
.otherCont1 { font-size:8px;text-align:right; color:#ba006e;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.other2 { font-size:11px; color:#007670;vertical-align:top;font-weight:bold;font-style:normal;float:left; width:95px; }
.otherCont2 { font-size:8px;text-align:right; color:#007670;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.other3 { font-size:11px; color:#3b0256;vertical-align:top;font-weight:bold;font-style:normal;float:left; width:95px; }
.otherCont3 { font-size:8px;text-align:right; color:#3b0256;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.other4 { font-size:11px; color:#00512b;vertical-align:top;font-weight:bold;font-style:normal;float:left; width:95px; }
.otherCont4 { font-size:8px;text-align:right; color:#00512b;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.other5 { font-size:11px; color:#a91024;vertical-align:top;font-weight:bold;font-style:normal;float:left; width:95px; }
.otherCont5 { font-size:8px;text-align:right; color:#a91024;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.other6 { font-size:11px; color:#b8471b;vertical-align:top;font-weight:bold;font-style:normal;float:left; width:95px; }
.otherCont6 { font-size:8px;text-align:right; color:#b8471b;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.other7 { font-size:11px; color:#7f1c7d;vertical-align:top;font-weight:bold;font-style:normal;float:left; width:95px; }
.otherCont7 { font-size:8px;text-align:right; color:#7f1c7d;font-family:Arial,Lucida Grande;font-style:normal;vertical-align:top;font-weight:bold;float:left; width:95px; }
.highlight { background-color:#bed6f8; }
.datestamp { padding-right:0px; font-size:11px; cursor:default;padding-top:1px;paddin/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.log4j.lf5.viewer.configure;

import java.awt.Color;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.tree.TreePath;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.lf5.LogLevel;
import org.apache.log4j.lf5.LogLevelFormatException;
import org.apache.log4j.lf5.viewer.LogBrokerMonitor;
import org.apache.log4j.lf5.viewer.LogTable;
import org.apache.log4j.lf5.viewer.LogTableColumn;
import org.apache.log4j.lf5.viewer.LogTableColumnFormatException;
import org.apache.log4j.lf5.viewer.categoryexplorer.CategoryExplorerModel;
import org.apache.log4j.lf5.viewer.categoryexplorer.CategoryExplorerTree;
import org.apache.log4j.lf5.viewer.categoryexplorer.CategoryNode;
import org.apache.log4j.lf5.viewer.categoryexplorer.CategoryPath;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * <p>ConfigurationManager handles the storage and retrival of the state of
 * the CategoryExplorer
 *
 * @author Richard Hurst
 * @author Brad Marlborough
 */

// Contributed by ThoughtWorks Inc.

public class ConfigurationManager extends Object {
  //--------------------------------------------------------------------------
  //   Constants:
  //--------------------------------------------------------------------------
  private static final String CONFIG_FILE_NAME = "lf5_configuration.xml";
  private static final String NAME = "name";
  private static final String PATH = "path";
  private static final String SELECTED = "selected";
  private static final String EXPANDED = "expanded";
  private static final String CATEGORY = "category";
  private static final String FIRST_CATEGORY_NAME = "Categories";
  private static final String LEVEL = "level";
  private static final String COLORLEVEL = "colorlevel";
  private static final String RED = "red";
  private static final String GREEN = "green";
  private static final String BLUE = "blue";
  private static final String COLUMN = "column";
  private static final String NDCTEXTFILTER = "searchtext";
  //--------------------------------------------------------------------------
  //   Protected Variables:
  //--------------------------------------------------------------------------

  //--------------------------------------------------------------------------
  //   Private Variables:
  //--------------------------------------------------------------------------
  private LogBrokerMonitor _monitor = null;
  private LogTable _table = null;

  //--------------------------------------------------------------------------
  //   Constructors:
  //--------------------------------------------------------------------------
  public ConfigurationManager(LogBrokerMonitor monitor, LogTable table) {
    super();
    _monitor = monitor;
    _table = table;
    load();
  }
  //--------------------------------------------------------------------------
  //   Public Methods:
  //---------------------------------------------------------------------g-bottom:1px; background-color:#a7a7a7; width:100%; float:left; text-align:right; color:#333333; font-weight:bold; font-style:italic; }
#chatAlert { float:left; border-bottom:1px solid #E8D091; padding:6px; width:100%; color:#A5754C; }
#chatAlertImage { float:left; }
#chatAlertText { float:left; margin-left:6px; margin-right:10px;}
#chatAlertClose { float:right; margin-right:10px; padding-right:6px; margin-top:0px; }
#chatAlertText a { color:#A5754C; }
#chatAlertText a:hover { color:#A5754C; text-decoration:none; }

.tsDisplay { display:block }.dsDisplay { display:block }
</style>
<meta name="sametime:hostname" content="messaging.ibm.com"/>
<meta name="sametime:providerId" content="Sametime"/>
<meta name="sametime:username" content="xiejia@cn.ibm.com"/>
<meta name="sametime:creationTime" content="20151204-103033 (+0800)"/>
<meta name="sametime:initiator" content="Hong Yao "/>
<meta name="sametime:lastActivityTime" content="20151204-204627 (+0800)"/>
<script language="javascript">conversationID = 'CONV$6ECDF08D06E26505'; 
var newMessage="New message. Click to scroll to the bottom."; 
var closeSrc ='file:/C:/Users/IBM_ADMIN/AppData/Roaming/IBM/Sametime/.config/org.eclipse.osgi/bundles/570/1/.cp/images/ST_Close_x_h1.png'; 
var closeHoverSrc='file:/C:/Users/IBM_ADMIN/AppData/Roaming/IBM/Sametime/.config/org.eclipse.osgi/bundles/570/1/.cp/images/ST_Close_x_h2.png'; 
var alertGradient='file:/C:/Users/IBM_ADMIN/AppData/Roaming/IBM/Sametime/.config/org.eclipse.osgi/bundles/572/1/.cp/images/chat_gradient.gif'; 
var closeTooltip="Close";</script><script language="javascript">
function resize() { var divT = document.getElementById("divTranscript"); divT.style.height = (document.body.clientHeight - getTopAreaHeight()) + "px"; divT.style.width = (document.body.clientWidth) + "px"; divT.style.overflow = "auto"; divT.style.position = "absolute"; divT.style.left = "0px"; divT.style.top = getTopAreaHeight() + "px";}
function getTopAreaHeight() { var chatAlert = document.getElementById("chatAlert"); if (chatAlert) { return chatAlert.clientHeight; } return document.getElementById("divBody").clientHeight;}
isChat=false; window.onresize=resize;
</script>
</head>
<body onload="try { resize(); } catch (e) {}">
<div id="divBody"></div><div id="divTranscript">                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
<!--START CONTENT-->

<div class="datestamp dsDisplay">Dec 4, 2015<span style="white-space:pre">   </span></div><div class="expansionx grayBackground dsDisplay"><br/></div><div class="expansion grayBackground"></div><div class="messageBlock grayBackground" username="yhyaoyh@cn.ibm.com" timestamp="1449196233683"><div  class="grayBackground" style="height:0"><br/></div><div class="other" title="Hong Yao [10:30:33]"  dir="ltr"  ><nobr>Hong Yao</nobr></div><br /><div style="clear:both;"></div></div><div  class="messageBlock grayBackground" timestamp="1449196233683"><div class="showTimestamp tsDisplay"><nobr>10:30:33</nobr></div><div class="message left" title="Hong Yao [10:30:33]"  dir="ltr" ><span style="font-size:10pt;font-family:Arial;color:#000000;" class="left">R1.4/IN996849<br />Update Legal Name for person with one contequiv IWM</span> <span class="system">&#160;<br/></span></div></div>
<div  class="messageBlock grayBackground" timestamp="1449196252933"><div class="showTimestamp tsDisplay"><nobr>10:30:52</nobr></div><div class="message left" title="Hong Yao [10:30:52]"  dir="ltr" ><span style="font-size:10pt;font-family:Arial;color:#000000;" class="left"> 这个好�-----

  public void save() {
    CategoryExplorerModel model = _monitor.getCategoryExplorerTree().getExplorerModel();
    CategoryNode root = model.getRootCategoryNode();

    StringBuffer xml = new StringBuffer(2048);
    openXMLDocument(xml);
    openConfigurationXML(xml);
    processLogRecordFilter(_monitor.getNDCTextFilter(), xml);
    processLogLevels(_monitor.getLogLevelMenuItems(), xml);
    processLogLevelColors(_monitor.getLogLevelMenuItems(),
        LogLevel.getLogLevelColorMap(), xml);
    processLogTableColumns(LogTableColumn.getLogTableColumns(), xml);
    processConfigurationNode(root, xml);
    closeConfigurationXML(xml);
    store(xml.toString());
  }

  public void reset() {
    deleteConfigurationFile();
    collapseTree();
    selectAllNodes();
  }

  public static String treePathToString(TreePath path) {
    // count begins at one so as to not include the 'Categories' - root category
    StringBuffer sb = new StringBuffer();
    CategoryNode n = null;
    Object[] objects = path.getPath();
    for (int i = 1; i < objects.length; i++) {
      n = (CategoryNode) objects[i];
      if (i > 1) {
        sb.append(".");
      }
      sb.append(n.getTitle());
    }
    return sb.toString();
  }

  //--------------------------------------------------------------------------
  //   Protected Methods:
  //--------------------------------------------------------------------------
  protected void load() {
    File file = new File(getFilename());
    if (file.exists()) {
      try {
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.
            newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        Document doc = docBuilder.parse(file);
        processRecordFilter(doc);
        processCategories(doc);
        processLogLevels(doc);
        processLogLevelColors(doc);
        processLogTableColumns(doc);
      } catch (Exception e) {
        // ignore all error and just continue as if there was no
        // configuration xml file but do report a message
        System.err.println("Unable process configuration file at " +
            getFilename() + ". Error Message=" + e.getMessage());
      }
    }

  }

  // Added in version 1.2 - reads in the NDC text filter from the
  // xml configuration file.  If the value of the filter is not null
  // or an empty string ("") then the manager will set the LogBrokerMonitor's
  // LogRecordFilter to use the NDC LogRecordFilter.  Otherwise, the
  // LogBrokerMonitor will use the default LogRecordFilter.
  protected void processRecordFilter(Document doc) {
    NodeList nodeList = doc.getElementsByTagName(NDCTEXTFILTER);

    // there is only one value stored
    Node n = nodeList.item(0);
    // add check for backwards compatibility  as this feature was added in
    // version 1.2
    if (n == null) {
      return;
    }

    NamedNodeMap map = n.getAttributes();
    String text = getValue(map, NAME);

    if (text == null || text.equals("")) {
      return;
    }
    _monitor.setNDCLogRecordFilter(text);
  }

  protected void processCategories(Document doc) {
    CategoryExplorerTree tree = _monitor.getCategoryExplorerTree();
    CategoryExplorerModel model = tree.getExplorerModel();
    NodeList nodeList = doc.getElementsByTagName(CATEGORY);

    // determine where the starting node is
    NamedNodeMap map = nodeList.item(0).getAttributes();
    int j = (getValue(map, NAME).equalsIgnoreCase(FIRST_CATEGORY_NAME)) ? 1 : 0;
    // iterate backwards throught the nodeList so that expansion of the
    // list can occur
    for (int i = nodeList.getLength() - 1; i >= j; i--) {
      Node n = nodeList.item(i);
      map = n.getAttributes();
      CategoryNode chnode = model.addCategory(new CategoryPath(getValue(map, PATH)));
      chnode.setSelected((getValue(map, SELECTED).equalsIgnoreCase("true")) ? true : false);
      if (getValue(map, EXPANDED).equalsIgnoreCase("true")) ;
      tree.expandPath(model.getTreePathToRoot(chnode));
    }

  }

  protected void processLogLevels(Document doc) {
    NodeList nodeLis��是你那个defect的问题吧</span> <span class="system">&#160;<br/></span></div></div>
<div class="expansion grayBackground"></div><div class="line"></div><div class="expansion"></div><div  class="messageBlock" username="xiejia@cn.ibm.com" timestamp="1449196263856"><div style="height:0"><br/></div><div class="myself" title="xiejia@cn.ibm.com - Jia DY Xie/China/IBM [10:31:03]"  dir="ltr"  ><nobr>xiejia@c...</nobr></div><br /><div style="clear:both;"></div></div><div  class="messageBlock" timestamp="1449196263856"><div class="showTimestamp tsDisplay"><nobr>10:31:03</nobr></div><div class="message left" title="xiejia@cn.ibm.com - Jia DY Xie/China/IBM [10:31:03]"  dir="ltr" ><span style="font-size:12pt;font-family:Arial;color:#000000;" class="left">这个是另外一个Defect，Jacky建的。</span> <span class="system">&#160;<br/></span></div></div>
<div  class="messageBlock" timestamp="1449196271085"><div class="showTimestamp tsDisplay"><nobr>10:31:11</nobr></div><div class="message left" title="xiejia@cn.ibm.com - Jia DY Xie/China/IBM [10:31:11]"  dir="ltr" ><span style="font-size:12pt;font-family:Arial;color:#000000;" class="left">我的是1064197</span> <span class="system">&#160;<br/></span></div></div>
<div  class="messageBlock" timestamp="1449196283059"><div class="showTimestamp tsDisplay"><nobr>10:31:23</nobr></div><div class="message left" title="xiejia@cn.ibm.com - Jia DY Xie/China/IBM [10:31:23]"  dir="ltr" ><span style="font-size:12pt;font-family:Arial;color:#000000;" class="left">好像是类似的问题</span> <span class="system">&#160;<br/></span></div></div>
<div class="expansion"></div><div class="line"></div><div class="expansion grayBackground"></div><div class="messageBlock grayBackground" username="yhyaoyh@cn.ibm.com" timestamp="1449196290592"><div  class="grayBackground" style="height:0"><br/></div><div class="other" title="Hong Yao [10:31:30]"  dir="ltr"  ><nobr>Hong Yao</nobr></div><br /><div style="clear:both;"></div></div><div  class="messageBlock grayBackground" timestamp="1449196290592"><div class="showTimestamp tsDisplay"><nobr>10:31:30</nobr></div><div class="message left" title="Hong Yao [10:31:30]"  dir="ltr" ><span style="font-size:10pt;font-family:Arial;color:#000000;" class="left">哦哦 </span> <span class="system">&#160;<br/></span></div></div>
<div  class="messageBlock grayBackground" timestamp="1449196354225"><div class="showTimestamp tsDisplay"><nobr>10:32:34</nobr></div><div class="message left" title="Hong Yao [10:32:34]"  dir="ltr" ><span style="font-size:10pt;font-family:Arial;color:#000000;" class="left">就是结果中两个LegalName 应该是只有一个是吗</span> <span class="system">&#160;<br/></span></div></div>
<div class="expansion grayBackground"></div><div class="line"></div><div class="expansion"></div><div  class="messageBlock" username="xiejia@cn.ibm.com" timestamp="1449196366905"><div style="height:0"><br/></div><div class="myself" title="xiejia@cn.ibm.com - Jia DY Xie/China/IBM [10:32:46]"  dir="ltr"  ><nobr>xiejia@c...</nobr></div><br /><div style="clear:both;"></div></div><div  class="messageBlock" timestamp="1449196366905"><div class="showTimestamp tsDisplay"><nobr>10:32:46</nobr></div><div class="message left" title="xiejia@cn.ibm.com - Jia DY Xie/China/IBM [10:32:46]"  dir="ltr" ><span style="font-size:12pt;font-family:Arial;color:#000000;" class="left">现在还不是，我还没有提交代码。</span> <span class="system">&#160;<br/></span></div></div>
<div  class="messageBlock" timestamp="1449196374272"><div class="showTimestamp tsDisplay"><nobr>10:32:54</nobr></div><div class="message left" title="xiejia@cn.ibm.com - Jia DY Xie/China/IBM [10:32:54]"  dir="ltr" ><span style="font-size:12pt;font-family:Arial;color:#000000;" class="left">应该是只有一个</span> <span class="system">&#160;<br/></span></div></div>
<div class="expansion"></div><div class="line"></div><div class="expansion grayBackground"></div><div class="messageBlock grayBackground" username="yhyaoyh@cn.ibm.com" timestamp="1449196379241"><div  class="grayBackground" style