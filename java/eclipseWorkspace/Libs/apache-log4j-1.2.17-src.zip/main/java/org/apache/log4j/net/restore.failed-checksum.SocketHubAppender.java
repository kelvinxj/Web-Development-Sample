uf einer neuen Registerkarte oder in einem neuen Fenster geöffnet)"><span class="keyword">IBM</span> <span class="keyword">Installation
Manager</span>-Downloads</a>. </p>
</div>
<div class="section"></div>
<div class="section" id="relnotes__problems"><h2 class="title sectiontitle">Bekannte Fehler</h2><p class="p">Bekannte Fehler werden als einzelne
Dokumente in der
<a class="xref" href="http://www.ibm.com/software/rational/support/" target="_blank" title="(Wird auf einer neuen Registerkarte oder in einem neuen Fenster geöffnet)">Support
Knowledge Base</a> erfasst. Diese Wissensbasis wird fortlaufend mit neuen Informationen aktualisiert, sobald Fehler und die
zugehörigen Lösungen bekannt werden. Durchsuchen Sie die Wissensbasis, wenn
Sie sich über Strategien zur Behebung von Problemen oder über Lösungen zu bestimmten Fehlern
informieren möchten.</p>
</div>
<div class="section" id="relnotes__support"><h2 class="title sectiontitle"><span class="keyword">IBM</span> <span class="keyword">Rational</span> Software Support </h2><p class="p">Kontaktinformationen
und Richtlinien oder Referenzmaterial für den Bezug
von Support finden Sie im <a class="xref" href="http://www14.software.ibm.com/webapp/set2/sas/f/handbook/home.html" target="_blank" title="(Wird auf einer neuen Registerkarte oder in einem neuen Fenster geöffnet)"><span class="keyword">IBM</span> Software
Support Handbook</a>. </p>
<p class="p">Häufig gestellte Fragen (FAQs), Auflistungen bekannter
Probleme und Korrekturen sowie andere unterstützungsrelevante Informationen
finden Sie im <a class="xref" href="http://www.ibm.com/software/awdtools/installmanager/support/index.html" target="_blank" title="(Wird auf einer neuen Registerkarte oder in einem neuen Fenster geöffnet)">Support-Portal von <span class="keyword">IBM</span> <span class="keyword">Installation
Manager</span></a>. </p>
<p class="p">Informationen zu Produktneuerungen, Terminen und weiteren Themen
finden Sie auf der
<a class="xref" href="http://www.ibm.com/software/rational/" target="_blank" title="(Wird auf einer neuen Registerkarte oder in einem neuen Fenster geöffnet)">Website für <span class="keyword">IBM</span>
<span class="keyword">Rational®</span>-Software</a>. </p>
<p class="p">Halten Sie die Hintergrundinformationen bereit, die Sie zur Beschreibung
Ihres Problems benötigen, wenn Sie sich an den Support für
<span class="keyword">IBM</span> <span class="keyword">Rational</span>-Software
wenden. Gehen Sie beim Beschreiben eines Problems dem
<span class="keyword">IBM</span> Software Support gegenüber so konkret
wie möglich vor und geben Sie alle relevanten Hintergrundinformationen weiter,
damit Ihnen der Berater bei der Lösung des Problems so effektiv
wie möglich helfen kann. Stellen Sie bereits im Vorfeld die Antworten auf die folgenden Fragen zusammen, um Zeit zu sparen:
 </p>
<ul class="ul"><li class="li">Welche Softwareversionen wurden ausgeführt, als das Problem auftrat?</li>
<li class="li">Verfügen Sie über Protokolle, Traces oder Nachrichten zu diesem Problem? </li>
<li class="li">Lässt sich das Problem reproduzieren? Wenn ja, welche Schritte führen Sie aus, um es zu reproduzieren?</li>
<li class="li">Gibt es eine Ausweichlösung zur Umgehung dieses Problems?</li>
<li class="li">Wenn es eine gibt, bereiten Sie sich darauf vor, die Umgehung zu beschreiben.</li>
</ul>
</div>
<div class="section" id="relnotes__trademarks"><h2 class="title sectiontitle">Bemerkungen</h2><p class="p">Die vorliegenden Informationen
wurden für Produkte und Services entwickelt, die auf dem deutschen Markt angeboten werden. </p>
<p class="p">Möglicherweise bietet <span class="keyword">IBM</span>
die in dieser Dokumentation beschriebenen Produkte, Services oder
Funktionen in anderen Ländern nicht an. Informationen über die gegenwärtig
im jeweiligen Land verfügbaren Produkte und Services sind beim zuständigen
<span class="keyword">IBM</span> Ansprechpartner erhältlich.
Hinweise auf <span class="keyword">IBM</span> Lizenzprogramme oder andere
/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.log4j.net;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Vector;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.helpers.CyclicBuffer;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

/**
  Sends {@link LoggingEvent} objects to a set of remote log servers,
  usually a {@link SocketNode SocketNodes}.
    
  <p>Acts just like {@link SocketAppender} except that instead of
  connecting to a given remote log server,
  <code>SocketHubAppender</code> accepts connections from the remote
  log servers as clients.  It can accept more than one connection.
  When a log event is received, the event is sent to the set of
  currently connected remote log servers. Implemented this way it does
  not require any update to the configuration file to send data to
  another remote log server. The remote log server simply connects to
  the host and port the <code>SocketHubAppender</code> is running on.
  
  <p>The <code>SocketHubAppender</code> does not store events such
  that the remote side will events that arrived after the
  establishment of its connection. Once connected, events arrive in
  order as guaranteed by the TCP protocol.

  <p>This implementation borrows heavily from the {@link
  SocketAppender}.

  <p>The SocketHubAppender has the following characteristics:
  
  <ul>
  
  <p><li>If sent to a {@link SocketNode}, logging is non-intrusive as
  far as the log event is concerned. In other words, the event will be
  logged with the same time stamp, {@link org.apache.log4j.NDC},
  location info as if it were logged locally.
  
  <p><li><code>SocketHubAppender</code> does not use a layout. It
  ships a serialized {@link LoggingEvent} object to the remote side.
  
  <p><li><code>SocketHubAppender</code> relies on the TCP
  protocol. Consequently, if the remote side is reachable, then log
  events will eventually arrive at remote client.
  
  <p><li>If no remote clients are attached, the logging requests are
  simply dropped.
  
  <p><li>Logging events are automatically <em>buffered</em> by the
  native TCP implementation. This means that if the link to remote
  client is slow but still faster than the rate of (log) event
  production, the application will not be affected by the slow network
  connection. However, if the network connection is slower then the
  rate of event production, then the local application can only
  progress at the network rate. In particular, if the network link to
  the the remote client is down, the application will be blocked.
  
  <p>On the other hand, if the network link is up, but the remote
  client is down, the client will not be blocked when making log
  requests but the log events will be lost due to client
  unavailability. 

  <p>The single remote client case extends to multiple clients
  connections. The rate of logging will be determined by the slowest
  link.
    
  <p><li>If the JVM hosting the <code>SocketHubAppender</code> exits
  before the <code>SocketHubAppender</code> is closed either
  explicitly or subsequent to garbage collection, then ther<span class="keyword">IBM</span> Produkte bedeuten nicht, dass nur Programme,
Produkte oder Services von
IBM verwendet werden können. Anstelle der <span class="keyword">IBM</span>
Produkte, Programme oder Services können auch andere, ihnen äquivalente
Produkte, Programme oder Services verwendet werden, solange diese keine
gewerblichen oder anderen
Schutzrechte von IBM verletzen. Die Verantwortung für den Betrieb von Produkten, Programmen und Services anderer Anbieter liegt
beim Kunden.  </p>
<p class="p">Für in dieser Dokumentation beschriebene Erzeugnisse und Verfahren
kann es <span class="keyword">IBM</span> Patente oder Patentanmeldungen geben.
Mit der Auslieferung dieser Dokumentation ist keine Lizenzierung dieser Patente verbunden. Lizenzanforderungen sind schriftlich an folgende Adresse zu richten (Anfragen an diese Adresse
müssen auf Englisch formuliert werden):  </p>
<p class="p"><em class="ph i"><span class="keyword">IBM</span> Director
of Licensing <br /><span class="keyword">IBM</span> Europe, Middle East &amp; Africa <br />Tour Descartes<br />
2, avenue Gambetta<br />
92066 Paris La Defense <br />France </em> </p>
<!-- <p class="p">For
license inquiries regarding double-byte (DBCS) information, contact
the <span class="keyword">IBM</span> Intellectual
Property Department in your country or send inquiries, in writing,
to:  </p>
<p class="p"><em class="ph i">Intellectual Property Licensing <br />Legal
and Intellectual Property Law<br /><span class="keyword">IBM</span> Japan,
Ltd.<br />19-21, Nihonbashi-Hakozakicho, Chuo-ku <br />Tokyo
103-8510, Japan</em>  </p> -->
<!-- <p class="p"><strong class="ph b">The following paragraph does not apply
to the United Kingdom or any other country where such provisions are
inconsistent with local law</strong>: <br />INTERNATIONAL BUSINESS
MACHINES CORPORATION PROVIDES THIS PUBLICATION "AS IS" WITHOUT WARRANTY
OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OR CONDITIONS OF NON-INFRINGEMENT, MERCHANTABILITY
OR FITNESS FOR A PARTICULAR PURPOSE. Some states do not allow disclaimer
of express or implied warranties in certain transactions, therefore,
this statement may not apply to you.  </p> -->
<p class="p">Trotz sorgfältiger Bearbeitung können
technische Ungenauigkeiten oder Druckfehler in dieser Veröffentlichung nicht ausgeschlossen werden. Die Angaben in diesem Handbuch werden in regelmäßigen Zeitabständen aktualisiert. Die Änderungen
werden in Überarbeitungen oder in Technical News Letters (TNLs) bekannt gegeben. <span class="keyword">IBM</span> kann jederzeit
Verbesserungen und/oder Änderungen an den in dieser Veröffentlichung beschriebenen Produkten
und/oder Programmen vornehmen.  </p>
<p class="p">Lizenznehmer des Programms, die Informationen zu diesem Produkt wünschen mit der Zielsetzung: (i) den
Austausch von Informationen zwischen unabhängig voneinander erstellten Programmen und anderen Programmen
(einschließlich des vorliegenden Programms) sowie (ii) die gemeinsame Nutzung der ausgetauschten
Informationen zu ermöglichen, wenden sich an folgende Adresse:  </p>
<p class="p"><em class="ph i">Intellectual Property Dept. for <span class="keyword">Rational</span> Software <br /><span class="keyword">IBM</span> Corporation <br />3600
Steeles Avenue East<br />Markham, ON<br />Canada  L3R
9Z7</em></p>
<p class="p">Die Bereitstellung dieser Informationen kann unter Umständen von bestimmten
Bedingungen - in einigen Fällen auch von der Zahlung einer Gebühr - abhängig sein.  </p>
<p class="p">Die Lieferung des im Dokument aufgeführten Lizenzprogramms
sowie des zugehörigen Lizenzmaterials erfolgt
auf der Basis der <span class="keyword">IBM</span> Rahmenvereinbarung bzw. der
Allgemeinen Geschäftsbedingungen von <span class="keyword">IBM</span>, der
<span class="keyword">IBM</span> Internationalen Nutzungsbedingungen für
Programmpakete oder einer äquivalenten Vereinbarung.</p>
</div>
<div class="section"><h2 class="title sectiontitle">Copyrightlizenz</he might
  be untransmitted data in the pipe which might be lost. This is a
  common problem on Windows based systems.
  
  <p>To avoid lost data, it is usually sufficient to {@link #close}
  the <code>SocketHubAppender</code> either explicitly or by calling
  the {@link org.apache.log4j.LogManager#shutdown} method before
  exiting the application.
  
  </ul>
     
  @author Mark Womack */

public class SocketHubAppender extends AppenderSkeleton {

  /**
     The default port number of the ServerSocket will be created on. */
  static final int DEFAULT_PORT = 4560;
  
  private int port = DEFAULT_PORT;
  private Vector oosList = new Vector();
  private ServerMonitor serverMonitor = null;
  private boolean locationInfo = false;
  private CyclicBuffer buffer = null;
  private String application;
  private boolean advertiseViaMulticastDNS;
  private ZeroConfSupport zeroConf;

  /**
   * The MulticastDNS zone advertised by a SocketHubAppender
   */
  public static final String ZONE = "_log4j_obj_tcpaccept_appender.local.";
  private ServerSocket serverSocket;


    public SocketHubAppender() { }

  /**
     Connects to remote server at <code>address</code> and <code>port</code>. */
  public
  SocketHubAppender(int _port) {
    port = _port;
    startServer();
  }

  /**
     Set up the socket server on the specified port.  */
  public
  void activateOptions() {
    if (advertiseViaMulticastDNS) {
      zeroConf = new ZeroConfSupport(ZONE, port, getName());
      zeroConf.advertise();
    }
    startServer();
  }

  /**
     Close this appender. 
     <p>This will mark the appender as closed and
     call then {@link #cleanUp} method. */
  synchronized
  public
  void close() {
    if(closed)
      return;

	LogLog.debug("closing SocketHubAppender " + getName());
    this.closed = true;
    if (advertiseViaMulticastDNS) {
      zeroConf.unadvertise();
    }
    cleanUp();

	LogLog.debug("SocketHubAppender " + getName() + " closed");
  }

  /**
     Release the underlying ServerMonitor thread, and drop the connections
     to all connected remote servers. */
  public 
  void cleanUp() {
    // stop the monitor thread
	LogLog.debug("stopping ServerSocket");
    serverMonitor.stopMonitor();
    serverMonitor = null;

    // close all of the connections
	LogLog.debug("closing client connections");
    while (oosList.size() != 0) {
      ObjectOutputStream oos = (ObjectOutputStream)oosList.elementAt(0);
      if(oos != null) {
        try {
        	oos.close();
        } catch(InterruptedIOException e) {
            Thread.currentThread().interrupt();
            LogLog.error("could not close oos.", e);
        } catch(IOException e) {
            LogLog.error("could not close oos.", e);
        }
        
        oosList.removeElementAt(0);     
      }
    }
  }

  /**
    Append an event to all of current connections. */
  public
  void append(LoggingEvent event) {
    if (event != null) {
      // set up location info if requested
      if (locationInfo) {
        event.getLocationInformation();
      }
      if (application != null) {
          event.setProperty("application", application);
        } 
        event.getNDC();
        event.getThreadName();
        event.getMDCCopy();
        event.getRenderedMessage();
        event.getThrowableStrRep();
        
      if (buffer != null) {
        buffer.add(event);
      }
    }

    // if no event or no open connections, exit now
    if ((event == null) || (oosList.size() == 0)) {
      return;
    }

	// loop through the current set of open connections, appending the event to each
    for (int streamCount = 0; streamCount < oosList.size(); streamCount++) {    	

      ObjectOutputStream oos = null;
      try {
        oos = (ObjectOutputStream)oosList.elementAt(streamCount);
      }
      catch (ArrayIndexOutOfBoundsException e) {
        // catch this, but just don't assign a value
        // this should not really occur as this method is
        // the only one that can remove oos's (besides cleanUp).
      }
      
      // list size changed unexpectedly? Just exit the a