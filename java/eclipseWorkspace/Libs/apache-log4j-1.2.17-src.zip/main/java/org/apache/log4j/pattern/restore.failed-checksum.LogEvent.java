fied by isMap finished in this job?
   * 
   * @param jip
   * @param isMap
   * @return true if finished, false otherwise
   */
  static boolean haveAllTasksFinished(JobInProgress jip, boolean isMap) {
    return ((isMap ? jip.runningMaps() : jip.runningReduces()) == 0);
  }

  private void writeFile(Path name)
      throws IOException {
    Configuration conf = new Configuration(false);
    SequenceFile.Writer writer =
        SequenceFile.createWriter(fs, conf, name, BytesWritable.class,
            BytesWritable.class, CompressionType.NONE);
    writer.append(new BytesWritable(), new BytesWritable());
    writer.close();
  }

  @Override
  public void configure(JobConf conf) {
    try {
      signalFileDir = new Path(conf.get("signal.dir.path"));
      numReducers = conf.getNumReduceTasks();
      fs = FileSystem.get(conf);
      String taskAttemptId = conf.get("mapred.task.id");
      if (taskAttemptId != null) {
        TaskAttemptID taskAttemptID = TaskAttemptID.forName(taskAttemptId);
        taskNumber = taskAttemptID.getTaskID().getId();
      }
    } catch (IOException ioe) {
      LOG.warn("Caught exception " + ioe);
    }
  }

  private FileStatus[] listSignalFiles(FileSystem fileSys, final boolean isMap)
      throws IOException {
    return fileSys.globStatus(new Path(signalFileDir.toString() + "/*"),
        new PathFilter() {
          @Override
          public boolean accept(Path path) {
            if (isMap && path.getName().startsWith(MAP_SIGFILE_PREFIX)) {
              LOG.debug("Found signal file : " + path.getName());
              return true;
            } else if (!isMap
                && path.getName().startsWith(REDUCE_SIGFILE_PREFIX)) {
              LOG.debug("Found signal file : " + path.getName());
              return true;
            }
            LOG.info("Didn't find any relevant signal files.");
            return false;
          }
        });
  }

  @Override
  public void map(NullWritable key, NullWritable value,
      OutputCollector<IntWritable, NullWritable> output, Reporter reporter)
      throws IOException {
    LOG.info(taskNumber + " has started.");
    FileStatus[] files = listSignalFiles(fs, true);
    String[] sigFileComps = files[0].getPath().getName().split("_");
    String signalType = sigFileComps[0];
    int noOfTasks = Integer.parseInt(sigFileComps[1]);

    while (!signalType.equals("MAPS") || taskNumber + 1 > noOfTasks) {
      LOG.info("Signal type found : " + signalType
          + " .Number of tasks to be finished by this signal : " + noOfTasks
          + " . My id : " + taskNumber);
      LOG.info(taskNumber + " is still alive.");
      try {
        reporter.progress();
        Thread.sleep(1000);
      } catch (InterruptedException ie) {
        LOG.info(taskNumber + " is still alive.");
        break;
      }
      files = listSignalFiles(fs, true);
      sigFileComps = files[0].getPath().getName().split("_");
      signalType = sigFileComps[0];
      noOfTasks = Integer.parseInt(sigFileComps[1]);
    }
    LOG.info("Signal type found : " + signalType
        + " .Number of tasks to be finished by this signal : " + noOfTasks
        + " . My id : " + taskNumber);
    // output numReduce number of random values, so that
    // each reducer will get one key each.
    for (int i = 0; i < numReducers; i++) {
      output.collect(new IntWritable(i), NullWritable.get());
    }

    LOG.info(taskNumber + " is finished.");
  }

  @Override
  public void reduce(IntWritable key, Iterator<NullWritable> values,
      OutputCollector<NullWritable, NullWritable> output, Reporter reporter)
      throws IOException {
    LOG.info(taskNumber + " has started.");
    FileStatus[] files = listSignalFiles(fs, false);
    String[] sigFileComps = files[0].getPath().getName().split("_");
    String signalType = sigFileComps[0];
    int noOfTasks = Integer.parseInt(sigFileComps[1]);

    while (!signalType.equals("REDUCES") || taskNumber + 1 > noOfTasks) {
      LOG.info("Signal type found : " + signalType
          + " .Number of tasks to be finished by this signal : " + no/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.log4j.pattern;

import org.apache.log4j.Category;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.apache.log4j.NDC;
import org.apache.log4j.Priority;
import org.apache.log4j.helpers.Loader;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LocationInfo;
import org.apache.log4j.spi.LoggerRepository;
import org.apache.log4j.spi.RendererSupport;
import org.apache.log4j.spi.ThrowableInformation;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

// Contributors:   Nelson Minar <nelson@monkey.org>
//                 Wolf Siberski
//                 Anders Kristensen <akristensen@dynamicsoft.com>

/**
 * This class is a copy of o.a.l.spi.LoggingEvent from
 * log4j 1.2.15 which has been renamed to keep
 * the same overall class name length to allow a
 * serialization written with a prior instance of o.a.l.spi.LoggingEvent
 * to be deserialized with this class just by mangling the class name
 * in the byte stream.
 *
 */
public class LogEvent implements java.io.Serializable {

  private static long startTime = System.currentTimeMillis();

  /** Fully qualified name of the calling category class. */
  transient public final String fqnOfCategoryClass;

  /** 
   * The category of the logging event. This field is not serialized
   * for performance reasons.
   *
   * <p>It is set by the LoggingEvent constructor or set by a remote
   * entity after deserialization.
   * 
   * @deprecated This field will be marked as private or be completely
   * removed in future releases. Please do not use it.
   * */
  transient private Category logger;

  /** 
   * <p>The category (logger) name.
   *   
   * @deprecated This field will be marked as private in future
   * releases. Please do not access it directly. Use the {@link
   * #getLoggerName} method instead.

   * */
  final public String categoryName;

  /** 
   * Level of logging event. Level cannot be serializable because it
   * is a flyweight.  Due to its special seralization it cannot be
   * declared final either.
   *   
   * <p> This field should not be accessed directly. You shoud use the
   * {@link #getLevel} method instead.
   *
   * @deprecated This field will be marked as private in future
   * releases. Please do not access it directly. Use the {@link
   * #getLevel} method instead.
   * */
  transient public Priority level;

  /** The nested diagnostic context (NDC) of logging event. */
  private String ndc;

  /** The mapped diagnostic context (MDC) of logging event. */
  private Hashtable mdcCopy;


  /** Have we tried to do an NDC lookup? If we did, there is no need
   *  to do it again.  Note that its value is always false when
   *  serialized. Thus, a receiving SocketNode will never use it's own
   *  (incorrect) NDC. See also writeObject method. */
  private boolean ndcLookupRequired = true;


  /** Have we tried to do an MDC lookup? If we did, there is no need
   *  to do it again.  Note that its value is always false when
   *  serialized. See also the getMDC and getMDCCopy methods.  */
  private boolean mOfTasks
          + " . My id : " + taskNumber);
      LOG.info(taskNumber + " is still alive.");
      try {
        reporter.progress();
        Thread.sleep(1000);
      } catch (InterruptedException ie) {
        LOG.info(taskNumber + " is still alive.");
        break;
      }
      files = listSignalFiles(fs, false);
      sigFileComps = files[0].getPath().getName().split("_");
      signalType = sigFileComps[0];
      noOfTasks = Integer.parseInt(sigFileComps[1]);
    }
    LOG.info("Signal type found : " + signalType
        + " .Number of tasks to be finished by this signal : " + noOfTasks
        + " . My id : " + taskNumber);
    LOG.info(taskNumber + " is finished.");
  }

  @Override
  public void close()
      throws IOException {
    // nothing
  }

  public JobID getJobId() {
    if (rJob == null) {
      return null;
    }
    return rJob.getID();
  }

  public int run(int numMapper, int numReducer)
      throws IOException {
    JobConf conf =
        getControlledMapReduceJobConf(getConf(), numMapper, numReducer);
    JobClient client = new JobClient(conf);
    rJob = client.submitJob(conf);
    while (!rJob.isComplete()) {
      try {
        Thread.sleep(1000);
      } catch (InterruptedException ie) {
        break;
      }
    }
    if (rJob.isSuccessful()) {
      return 0;
    }
    return 1;
  }

  private JobConf getControlledMapReduceJobConf(Configuration clusterConf,
      int numMapper, int numReducer)
      throws IOException {
    setConf(clusterConf);
    initialize();
    JobConf conf = new JobConf(getConf(), ControlledMapReduceJob.class);
    conf.setJobName("ControlledJob");
    conf.set("signal.dir.path", signalFileDir.toString());
    conf.setNumMapTasks(numMapper);
    conf.setNumReduceTasks(numReducer);
    conf.setMapperClass(ControlledMapReduceJob.class);
    conf.setMapOutputKeyClass(IntWritable.class);
    conf.setMapOutputValueClass(NullWritable.class);
    conf.setReducerClass(ControlledMapReduceJob.class);
    conf.setOutputKeyClass(NullWritable.class);
    conf.setOutputValueClass(NullWritable.class);
    conf.setInputFormat(ControlledMapReduceJob.class);
    FileInputFormat.addInputPath(conf, new Path("ignored"));
    conf.setOutputFormat(NullOutputFormat.class);
    conf.setMapSpeculativeExecution(false);
    conf.setReduceSpeculativeExecution(false);

    // Set the following for reduce tasks to be able to be started running
    // immediately along with maps.
    conf.set("mapred.reduce.slowstart.completed.maps", String.valueOf(0));

    return conf;
  }

  @Override
  public int run(String[] args)
      throws Exception {
    numMappers = Integer.parseInt(args[0]);
    numReducers = Integer.parseInt(args[1]);
    return run(numMappers, numReducers);
  }

  @Override
  public int getPartition(IntWritable k, NullWritable v, int numPartitions) {
    return k.get() % numPartitions;
  }

  @Override
  public RecordReader<NullWritable, NullWritable> getRecordReader(
      InputSplit split, JobConf job, Reporter reporter) {
    LOG.debug("Inside RecordReader.getRecordReader");
    return new RecordReader<NullWritable, NullWritable>() {
      private int pos = 0;

      public void close() {
        // nothing
      }

      public NullWritable createKey() {
        return NullWritable.get();
      }

      public NullWritable createValue() {
        return NullWritable.get();
      }

      public long getPos() {
        return pos;
      }

      public float getProgress() {
        return pos * 100;
      }

      public boolean next(NullWritable key, NullWritable value) {
        if (pos++ == 0) {
          LOG.debug("Returning the next record");
          return true;
        }
        LOG.debug("No more records. Returning none.");
        return false;
      }
    };
  }

  @Override
  public InputSplit[] getSplits(JobConf job, int numSplits) {
    LOG.debug("Inside InputSplit.getSplits");
    InputSplit[] ret = new InputSplit[numSplits];
    for (int i = 0; i < numSplits; ++i) {
      ret[i] = new EmptySplit();
    }
    return ret;
  }

  public static class EmptySplitdcCopyLookupRequired = true;

  /** The application supplied message of logging event. */
  transient private Object message;

  /** The application supplied message rendered through the log4j
      objet rendering mechanism.*/
  private String renderedMessage;

  /** The name of thread in which this logging event was generated. */
  private String threadName;


  /** This
      variable contains information about this event's throwable
  */
  private ThrowableInformation throwableInfo;

  /** The number of milliseconds elapsed from 1/1/1970 until logging event
      was created. */
  public final long timeStamp;
  /** Location information for the caller. */
  private LocationInfo locationInfo;

  // Serialization
  static final long serialVersionUID = -868428216207166145L;

  static final Integer[] PARAM_ARRAY = new Integer[1];
  static final String TO_LEVEL = "toLevel";
  static final Class[] TO_LEVEL_PARAMS = new Class[] {int.class};
  static final Hashtable methodCache = new Hashtable(3); // use a tiny table

  /**
     Instantiate a LoggingEvent from the supplied parameters.

     <p>Except {@link #timeStamp} all the other fields of
     <code>LoggingEvent</code> are filled when actually needed.
     <p>
     @param logger The logger generating this event.
     @param level The level of this event.
     @param message  The message of this event.
     @param throwable The throwable of this event.  */
  public LogEvent(String fqnOfCategoryClass, Category logger,
		      Priority level, Object message, Throwable throwable) {
    this.fqnOfCategoryClass = fqnOfCategoryClass;
    this.logger = logger;
    this.categoryName = logger.getName();
    this.level = level;
    this.message = message;
    if(throwable != null) {
      this.throwableInfo = new ThrowableInformation(throwable);
    }
    timeStamp = System.currentTimeMillis();
  }

  /**
     Instantiate a LoggingEvent from the supplied parameters.

     <p>Except {@link #timeStamp} all the other fields of
     <code>LoggingEvent</code> are filled when actually needed.
     <p>
     @param logger The logger generating this event.
     @param timeStamp the timestamp of this logging event
     @param level The level of this event.
     @param message  The message of this event.
     @param throwable The throwable of this event.  */
  public LogEvent(String fqnOfCategoryClass, Category logger,
		      long timeStamp, Priority level, Object message,
		      Throwable throwable) {
    this.fqnOfCategoryClass = fqnOfCategoryClass;
    this.logger = logger;
    this.categoryName = logger.getName();
    this.level = level;
    this.message = message;
    if(throwable != null) {
      this.throwableInfo = new ThrowableInformation(throwable);
    }

    this.timeStamp = timeStamp;
  }

    /**
       Create new instance.
       @since 1.2.15
       @param fqnOfCategoryClass Fully qualified class name
                 of Logger implementation.
       @param logger The logger generating this event.
       @param timeStamp the timestamp of this logging event
       @param level The level of this event.
       @param message  The message of this event.
       @param threadName thread name
       @param throwable The throwable of this event.
       @param ndc Nested diagnostic context
       @param info Location info
       @param properties MDC properties
     */
    public LogEvent(final String fqnOfCategoryClass,
                        final Logger logger,
                        final long timeStamp,
                        final Level level,
                        final Object message,
                        final String threadName,
                        final ThrowableInformation throwable,
                        final String ndc,
                        final LocationInfo info,
                        final java.util.Map properties) {
      super();
      this.fqnOfCategoryClass = fqnOfCategoryClass;
      this.logger = logger;
      if (logger != null) {
          categoryName = logger.getName();
      } else {
          categoryName = null;
      }
      this.level implements InputSplit {
    public void write(DataOutput out)
        throws IOException {
    }

    public void readFields(DataInput in)
        throws IOException {
    }

    public long getLength() {
      return 0L;
    }

    public String[] getLocations() {
      return new String[0];
    }
  }

  static class ControlledMapReduceJobRunner extends Thread {
    private JobConf conf;
    private ControlledMapReduceJob job;
    private JobID jobID;

    private int numMappers;
    private int numReducers;

    public ControlledMapReduceJobRunner() {
      this(new JobConf(), 5, 5);
    }

    public ControlledMapReduceJobRunner(JobConf cnf, int numMap, int numRed) {
      this.conf = cnf;
      this.numMappers = numMap;
      this.numReducers = numRed;
    }

    public ControlledMapReduceJob getJob() {
      while (job == null) {
        try {
          Thread.sleep(1000);
        } catch (InterruptedException ie) {
          LOG.info(ControlledMapReduceJobRunner.class.getName()
              + " is interrupted.");
          break;
        }
      }
      return job;
    }

    public JobID getJobID()
        throws IOException {
      ControlledMapReduceJob job = getJob();
      JobID id = job.getJobId();
      while (id == null) {
        id = job.getJobId();
        try {
          Thread.sleep(1000);
        } catch (InterruptedException ie) {
          LOG.info(ControlledMapReduceJobRunner.class.getName()
              + " is interrupted.");
          break;
        }
      }
      return id;
    }

    @Override
    public void run() {
      if (job != null) {
        LOG.warn("Job is already running.");
        return;
      }
      try {
        job = new ControlledMapReduceJob();
        int ret =
            ToolRunner.run(this.conf, job, new String[] {
                String.valueOf(numMappers), String.valueOf(numReducers) });
        LOG.info("Return value for the job : " + ret);
      } catch (Exception e) {
        LOG.warn("Caught exception : " + StringUtils.stringifyException(e));
      }
    }

    static ControlledMapReduceJobRunner getControlledMapReduceJobRunner(
        JobConf conf, int numMappers, int numReducers) {
      return new ControlledMapReduceJobRunner(conf, numMappers, numReducers);
    }
  }
}
