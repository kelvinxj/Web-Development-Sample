[11/7/19 16:48:02:068 CST]     FFDC Exception:java.lang.NullPointerException SourceId:com.ibm.ws.ssl.core.SSLConfigManager.parseConfigURL ProbeId:2567 Reporter:com.ibm.ws.ssl.config.SSLConfigManager@eeb6f93
java.lang.NullPointerException
	at java.util.Hashtable.put(Hashtable.java:506)
	at com.ibm.ws.ssl.config.SSLConfigManager.parseConfigURL(SSLConfigManager.java:2856)
	at com.ibm.ws.ssl.config.SSLConfigManager.initializeClientSSL(SSLConfigManager.java:410)
	at com.ibm.ws.management.connector.soap.SOAPConnectorClient.<init>(SOAPConnectorClient.java:224)
	at sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)
	at sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:83)
	at sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:57)
	at java.lang.reflect.Constructor.newInstance(Constructor.java:437)
	at com.ibm.websphere.management.AdminClientFactory.createAdminClientPrivileged(AdminClientFactory.java:457)
	at com.ibm.websphere.management.AdminClientFactory.access$000(AdminClientFactory.java:127)
	at com.ibm.websphere.management.AdminClientFactory$1.run(AdminClientFactory.java:210)
	at com.ibm.ws.security.util.AccessController.doPrivileged(AccessController.java:63)
	at com.ibm.websphere.management.AdminClientFactory.createAdminClient(AdminClientFactory.java:206)
	at com.ibm.ws.scripting.CommonScriptingObject.connectToAdminService(CommonScriptingObject.java:123)
	at com.ibm.ws.scripting.CommonScriptingObject.<init>(CommonScriptingObject.java:104)
	at com.ibm.ws.scripting.AdminControlClient.<init>(AdminControlClient.java:170)
	at com.ibm.ws.scripting.AbstractShell.createControlClient(AbstractShell.java:1366)
	at com.ibm.ws.scripting.AbstractShell.run(AbstractShell.java:2359)
	at com.ibm.ws.scripting.WasxShell.main(WasxShell.java:1256)

CapturedDataElements begin
arg BEGIN:com.ibm.ws.ssl.config.SSLConfigManager@eeb6f93
com.ibm.ws.ssl.config.SSLConfigManager::tc BEGIN:com.ibm.ejs.ras.TraceComponent@a174c5c0
 com.ibm.ejs.ras.TraceElement::ivLevel:10
 com.ibm.ejs.ras.TraceElement::ivName:com.ibm.ws.ssl.config.SSLConfigManager
 com.ibm.ejs.ras.TraceElement::ivDebugEnabled:false
 com.ibm.ejs.ras.TraceElement::ivEventEnabled:false
 com.ibm.ejs.ras.TraceElement::ivEntryEnabled:false
 com.ibm.ejs.ras.TraceElement::ivDetailEnabled:false
 com.ibm.ejs.ras.TraceElement::ivConfigEnabled:false
 com.ibm.ejs.ras.TraceElement::ivInfoEnabled:true
 com.ibm.ejs.ras.TraceElement::ivServiceEnabled:true
 com.ibm.ejs.ras.TraceElement::ivWarningEnabled:true
 com.ibm.ejs.ras.TraceElement::ivErrorEnabled:true
 com.ibm.ejs.ras.TraceElement::ivFatalEnabled:true
 com.ibm.ejs.ras.TraceComponent::defaultMessageFile:com.ibm.ejs.resources.seriousMessages
 com.ibm.ejs.ras.TraceComponent::EXTENSION_NAME_DPID:DiagnosticProvider
 com.ibm.ejs.ras.TraceComponent::ivDumpEnabled:false
 com.ibm.ejs.ras.TraceComponent::ivResourceBundleName:com.ibm.ws.ssl.resources.ssl
 com.ibm.ejs.ras.TraceComponent::ivTraceClass:class com.ibm.ws.ssl.config.SSLConfigManager
 com.ibm.ejs.ras.TraceComponent::ivLogger:null
 com.ibm.ejs.ras.TraceComponent::ivDiagnosticProviderID:null
 com.ibm.ejs.ras.TraceComponent::anyTracingEnabled:null
 END:com.ibm.ejs.ras.TraceComponent@a174c5c0

com.ibm.ws.ssl.config.SSLConfigManager::thisClass:com.ibm.ws.ssl.config.SSLConfigManager@eeb6f93
com.ibm.ws.ssl.config.SSLConfigManager::isServerProcess:false
com.ibm.ws.ssl.config.SSLConfigManager::clientSSLInitializedOnce:false
com.ibm.ws.ssl.config.SSLConfigManager::setSecurityPropsOnce:false
com.ibm.ws.ssl.config.SSLConfigManager::keyStoreManager BEGIN:com.ibm.ws.ssl.config.KeyStoreManager@f3568eb7
 com.ibm.ws.ssl.config.KeyStoreManager::tc BEGIN:com.ibm.ejs.ras.TraceComponent@1a1f7bb6
  com.ibm.ejs.ras.TraceElement::ivLevel:10
  com.ibm.ejs.ras.TraceElement::ivName:com.ibm.ws.ssl.config.KeyStoreManager
  com.ibm.ejs.ras.TraceElement::ivDebugEnabled:false
  com.ibm.ejs.ras.TraceElement::ivEventEnabled:false
  com.ibm.ejs.ras.TraceElement::ivEntryEnabled:fal/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



package org.apache.log4j;

import java.io.IOException;
import java.io.File;
import java.io.InterruptedIOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Locale;

import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

/**
   DailyRollingFileAppender extends {@link FileAppender} so that the
   underlying file is rolled over at a user chosen frequency.
   
   DailyRollingFileAppender has been observed to exhibit 
   synchronization issues and data loss.  The log4j extras
   companion includes alternatives which should be considered
   for new deployments and which are discussed in the documentation
   for org.apache.log4j.rolling.RollingFileAppender.

   <p>The rolling schedule is specified by the <b>DatePattern</b>
   option. This pattern should follow the {@link SimpleDateFormat}
   conventions. In particular, you <em>must</em> escape literal text
   within a pair of single quotes. A formatted version of the date
   pattern is used as the suffix for the rolled file name.

   <p>For example, if the <b>File</b> option is set to
   <code>/foo/bar.log</code> and the <b>DatePattern</b> set to
   <code>'.'yyyy-MM-dd</code>, on 2001-02-16 at midnight, the logging
   file <code>/foo/bar.log</code> will be copied to
   <code>/foo/bar.log.2001-02-16</code> and logging for 2001-02-17
   will continue in <code>/foo/bar.log</code> until it rolls over
   the next day.

   <p>Is is possible to specify monthly, weekly, half-daily, daily,
   hourly, or minutely rollover schedules.

   <p><table border="1" cellpadding="2">
   <tr>
   <th>DatePattern</th>
   <th>Rollover schedule</th>
   <th>Example</th>

   <tr>
   <td><code>'.'yyyy-MM</code>
   <td>Rollover at the beginning of each month</td>

   <td>At midnight of May 31st, 2002 <code>/foo/bar.log</code> will be
   copied to <code>/foo/bar.log.2002-05</code>. Logging for the month
   of June will be output to <code>/foo/bar.log</code> until it is
   also rolled over the next month.

   <tr>
   <td><code>'.'yyyy-ww</code>

   <td>Rollover at the first day of each week. The first day of the
   week depends on the locale.</td>

   <td>Assuming the first day of the week is Sunday, on Saturday
   midnight, June 9th 2002, the file <i>/foo/bar.log</i> will be
   copied to <i>/foo/bar.log.2002-23</i>.  Logging for the 24th week
   of 2002 will be output to <code>/foo/bar.log</code> until it is
   rolled over the next week.

   <tr>
   <td><code>'.'yyyy-MM-dd</code>

   <td>Rollover at midnight each day.</td>

   <td>At midnight, on March 8th, 2002, <code>/foo/bar.log</code> will
   be copied to <code>/foo/bar.log.2002-03-08</code>. Logging for the
   9th day of March will be output to <code>/foo/bar.log</code> until
   it is rolled over the next day.

   <tr>
   <td><code>'.'yyyy-MM-dd-a</code>

   <td>Rollover at midnight and midday of each day.</td>

   <td>At noon, on March 9th, 2002, <code>/foo/bar.log</code> will be
   copied to <code>/foo/bar.log.2002-03-09-AM</code>. Logging for the
   afternoon of the 9th will be output to <code>/foo/bar.log</code>
   until it is rolled over at midnight.

   <tr>
   <td><code>'.'yyyy-MM-dd-HH</code>

   <td>Rose
  com.ibm.ejs.ras.TraceElement::ivDetailEnabled:false
  com.ibm.ejs.ras.TraceElement::ivConfigEnabled:false
  com.ibm.ejs.ras.TraceElement::ivInfoEnabled:true
  com.ibm.ejs.ras.TraceElement::ivServiceEnabled:true
  com.ibm.ejs.ras.TraceElement::ivWarningEnabled:true
  com.ibm.ejs.ras.TraceElement::ivErrorEnabled:true
  com.ibm.ejs.ras.TraceElement::ivFatalEnabled:true
  com.ibm.ejs.ras.TraceComponent::defaultMessageFile:com.ibm.ejs.resources.seriousMessages
  com.ibm.ejs.ras.TraceComponent::EXTENSION_NAME_DPID:DiagnosticProvider
  com.ibm.ejs.ras.TraceComponent::ivDumpEnabled:false
  com.ibm.ejs.ras.TraceComponent::ivResourceBundleName:com.ibm.ws.ssl.resources.ssl
  com.ibm.ejs.ras.TraceComponent::ivTraceClass:class com.ibm.ws.ssl.config.KeyStoreManager
  com.ibm.ejs.ras.TraceComponent::ivLogger:null
  com.ibm.ejs.ras.TraceComponent::ivDiagnosticProviderID:null
  com.ibm.ejs.ras.TraceComponent::anyTracingEnabled:null
  END:com.ibm.ejs.ras.TraceComponent@1a1f7bb6

 com.ibm.ws.ssl.config.KeyStoreManager::thisClass:com.ibm.ws.ssl.config.KeyStoreManager@f3568eb7
 com.ibm.ws.ssl.config.KeyStoreManager::keyStoreMap BEGIN:java.util.HashMap@4443a1ee
  {
  }
  END:java.util.HashMap@4443a1ee

 com.ibm.ws.ssl.config.KeyStoreManager::acceleratorMap BEGIN:java.util.HashMap@f92e31c4
  {
  }
  END:java.util.HashMap@f92e31c4

 com.ibm.ws.ssl.config.KeyStoreManager::expandMap BEGIN:java.util.HashMap@f606514f
  {
  key:cn=${hostname},o=IBM,c=US
  value:cn=DESKTOP-C6LA5OD,o=IBM,c=US
  key:${hostname}
  value:DESKTOP-C6LA5OD
  }
  END:java.util.HashMap@f606514f

 com.ibm.ws.ssl.config.KeyStoreManager::host:DESKTOP-C6LA5OD
 com.ibm.ws.ssl.config.KeyStoreManager::pkcsStoreList BEGIN:com.ibm.ws.ssl.core.WSPKCSInKeyStoreList@58618bf
  com.ibm.ws.ssl.core.WSPKCSInKeyStoreList::theV BEGIN:java.util.Vector@a9006fbc
   {
   }
   END:java.util.Vector@a9006fbc

  com.ibm.ws.ssl.core.WSPKCSInKeyStoreList::tc BEGIN:com.ibm.ejs.ras.TraceComponent@20ec2a7a
   com.ibm.ejs.ras.TraceElement::ivLevel:10
   com.ibm.ejs.ras.TraceElement::ivName:com.ibm.ws.ssl.core.WSPKCSInKeyStoreList
   com.ibm.ejs.ras.TraceElement::ivDebugEnabled:false
   com.ibm.ejs.ras.TraceElement::ivEventEnabled:false
   com.ibm.ejs.ras.TraceElement::ivEntryEnabled:false
   com.ibm.ejs.ras.TraceElement::ivDetailEnabled:false
   com.ibm.ejs.ras.TraceElement::ivConfigEnabled:false
   com.ibm.ejs.ras.TraceElement::ivInfoEnabled:true
   com.ibm.ejs.ras.TraceElement::ivServiceEnabled:true
   com.ibm.ejs.ras.TraceElement::ivWarningEnabled:true
   com.ibm.ejs.ras.TraceElement::ivErrorEnabled:true
   com.ibm.ejs.ras.TraceElement::ivFatalEnabled:true
   com.ibm.ejs.ras.TraceComponent::defaultMessageFile:com.ibm.ejs.resources.seriousMessages
   com.ibm.ejs.ras.TraceComponent::EXTENSION_NAME_DPID:DiagnosticProvider
   com.ibm.ejs.ras.TraceComponent::ivDumpEnabled:false
   com.ibm.ejs.ras.TraceComponent::ivResourceBundleName:com.ibm.ws.ssl.resources.ssl
   com.ibm.ejs.ras.TraceComponent::ivTraceClass:class com.ibm.ws.ssl.core.WSPKCSInKeyStoreList
   com.ibm.ejs.ras.TraceComponent::ivLogger:null
   com.ibm.ejs.ras.TraceComponent::ivDiagnosticProviderID:null
   com.ibm.ejs.ras.TraceComponent::anyTracingEnabled:null
   END:com.ibm.ejs.ras.TraceComponent@20ec2a7a

  END:com.ibm.ws.ssl.core.WSPKCSInKeyStoreList@58618bf

 END:com.ibm.ws.ssl.config.KeyStoreManager@f3568eb7

com.ibm.ws.ssl.config.SSLConfigManager::globalConfigProperties BEGIN:java.util.Properties@5b012a37
 {
 }
 END:java.util.Properties@5b012a37

com.ibm.ws.ssl.config.SSLConfigManager::sslConfigMap BEGIN:java.util.HashMap@e73f1ac
 {
 }
 END:java.util.HashMap@e73f1ac

com.ibm.ws.ssl.config.SSLConfigManager::keyManagerArrayList BEGIN:java.util.ArrayList@554748e0
 {
 }
 END:java.util.ArrayList@554748e0

com.ibm.ws.ssl.config.SSLConfigManager::trustManagerArrayList BEGIN:java.util.ArrayList@b0aa64a4
 {
 }
 END:java.util.ArrayList@b0aa64a4

com.ibm.ws.ssl.config.SSLConfigManager::sslConfigDynamicSelectionMap BEGIN:java.util.HashMap@7fbaf47f
 {
 }
 Ellover at the top of every hour.</td>

   <td>At approximately 11:00.000 o'clock on March 9th, 2002,
   <code>/foo/bar.log</code> will be copied to
   <code>/foo/bar.log.2002-03-09-10</code>. Logging for the 11th hour
   of the 9th of March will be output to <code>/foo/bar.log</code>
   until it is rolled over at the beginning of the next hour.


   <tr>
   <td><code>'.'yyyy-MM-dd-HH-mm</code>

   <td>Rollover at the beginning of every minute.</td>

   <td>At approximately 11:23,000, on March 9th, 2001,
   <code>/foo/bar.log</code> will be copied to
   <code>/foo/bar.log.2001-03-09-10-22</code>. Logging for the minute
   of 11:23 (9th of March) will be output to
   <code>/foo/bar.log</code> until it is rolled over the next minute.

   </table>

   <p>Do not use the colon ":" character in anywhere in the
   <b>DatePattern</b> option. The text before the colon is interpeted
   as the protocol specificaion of a URL which is probably not what
   you want.


   @author Eirik Lygre
   @author Ceki G&uuml;lc&uuml;*/
public class DailyRollingFileAppender extends FileAppender {


  // The code assumes that the following constants are in a increasing
  // sequence.
  static final int TOP_OF_TROUBLE=-1;
  static final int TOP_OF_MINUTE = 0;
  static final int TOP_OF_HOUR   = 1;
  static final int HALF_DAY      = 2;
  static final int TOP_OF_DAY    = 3;
  static final int TOP_OF_WEEK   = 4;
  static final int TOP_OF_MONTH  = 5;


  /**
     The date pattern. By default, the pattern is set to
     "'.'yyyy-MM-dd" meaning daily rollover.
   */
  private String datePattern = "'.'yyyy-MM-dd";

  /**
     The log file will be renamed to the value of the
     scheduledFilename variable when the next interval is entered. For
     example, if the rollover period is one hour, the log file will be
     renamed to the value of "scheduledFilename" at the beginning of
     the next hour. 

     The precise time when a rollover occurs depends on logging
     activity. 
  */
  private String scheduledFilename;

  /**
     The next time we estimate a rollover should occur. */
  private long nextCheck = System.currentTimeMillis () - 1;

  Date now = new Date();

  SimpleDateFormat sdf;

  RollingCalendar rc = new RollingCalendar();

  int checkPeriod = TOP_OF_TROUBLE;

  // The gmtTimeZone is used only in computeCheckPeriod() method.
  static final TimeZone gmtTimeZone = TimeZone.getTimeZone("GMT");


  /**
     The default constructor does nothing. */
  public DailyRollingFileAppender() {
  }

  /**
    Instantiate a <code>DailyRollingFileAppender</code> and open the
    file designated by <code>filename</code>. The opened filename will
    become the ouput destination for this appender.

    */
  public DailyRollingFileAppender (Layout layout, String filename,
				   String datePattern) throws IOException {
    super(layout, filename, true);
    this.datePattern = datePattern;
    activateOptions();
  }

  /**
     The <b>DatePattern</b> takes a string in the same format as
     expected by {@link SimpleDateFormat}. This options determines the
     rollover schedule.
   */
  public void setDatePattern(String pattern) {
    datePattern = pattern;
  }

  /** Returns the value of the <b>DatePattern</b> option. */
  public String getDatePattern() {
    return datePattern;
  }

  public void activateOptions() {
    super.activateOptions();
    if(datePattern != null && fileName != null) {
      now.setTime(System.currentTimeMillis());
      sdf = new SimpleDateFormat(datePattern);
      int type = computeCheckPeriod();
      printPeriodicity(type);
      rc.setType(type);
      File file = new File(fileName);
      scheduledFilename = fileName+sdf.format(new Date(file.lastModified()));

    } else {
      LogLog.error("Either File or DatePattern options are not set for appender ["
		   +name+"].");
    }
  }

  void printPeriodicity(int type) {
    switch(type) {
    case TOP_OF_MINUTE:
      LogLog.debug("Appender ["+name+"] to be rolled every minute.");
      break;
    case TOP_OF_HOUR:
      LogLog.debug("Appender ["+name
		   +"] to be rolled on t