<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- NewPage -->
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>FairBlockingQueue.ItemFuture (Apache Tomcat 7.0.91 API Documentation)</title>
<link rel="stylesheet" type="text/css" href="../../../../../stylesheet.css" title="Style">
</head>
<body>
<script type="text/javascript"><!--
    if (location.href.indexOf('is-external=true') == -1) {
        parent.document.title="FairBlockingQueue.ItemFuture (Apache Tomcat 7.0.91 API Documentation)";
    }
//-->
</script>
<noscript>
<div>JavaScript is disabled on your browser.</div>
</noscript>
<!-- ========= START OF TOP NAVBAR ======= -->
<div class="topNav"><a name="navbar_top">
<!--   -->
</a><a href="#skip-navbar_top" title="Skip navigation links"></a><a name="navbar_top_firstrow">
<!--   -->
</a>
<ul class="navList" title="Navigation">
<li><a href="../../../../../overview-summary.html">Overview</a></li>
<li><a href="package-summary.html">Package</a></li>
<li class="navBarCell1Rev">Class</li>
<li><a href="package-tree.html">Tree</a></li>
<li><a href="../../../../../deprecated-list.html">Deprecated</a></li>
<li><a href="../../../../../index-all.html">Index</a></li>
<li><a href="../../../../../help-doc.html">Help</a></li>
</ul>
<div class="aboutLanguage"><em><b>Apache Tomcat 7.0.91</b></em></div>
</div>
<div class="subNav">
<ul class="navList">
<li><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.FairIterator.html" title="class in org.apache.tomcat.jdbc.pool"><span class="strong">Prev Class</span></a></li>
<li><a href="../../../../../org/apache/tomcat/jdbc/pool/JdbcInterceptor.html" title="class in org.apache.tomcat.jdbc.pool"><span class="strong">Next Class</span></a></li>
</ul>
<ul class="navList">
<li><a href="../../../../../index.html?org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" target="_top">Frames</a></li>
<li><a href="FairBlockingQueue.ItemFuture.html" target="_top">No Frames</a></li>
</ul>
<ul class="navList" id="allclasses_navbar_top">
<li><a href="../../../../../allclasses-noframe.html">All Classes</a></li>
</ul>
<div>
<script type="text/javascript"><!--
  allClassesLink = document.getElementById("allclasses_navbar_top");
  if(window==top) {
    allClassesLink.style.display = "block";
  }
  else {
    allClassesLink.style.display = "none";
  }
  //-->
</script>
</div>
<div>
<ul class="subNavList">
<li>Summary:&nbsp;</li>
<li>Nested&nbsp;|&nbsp;</li>
<li><a href="#field_summary">Field</a>&nbsp;|&nbsp;</li>
<li><a href="#constructor_summary">Constr</a>&nbsp;|&nbsp;</li>
<li><a href="#method_summary">Method</a></li>
</ul>
<ul class="subNavList">
<li>Detail:&nbsp;</li>
<li><a href="#field_detail">Field</a>&nbsp;|&nbsp;</li>
<li><a href="#constructor_detail">Constr</a>&nbsp;|&nbsp;</li>
<li><a href="#method_detail">Method</a></li>
</ul>
</div>
<a name="skip-navbar_top">
<!--   -->
</a></div>
<!-- ========= END OF TOP NAVBAR ========= -->
<!-- ======== START OF CLASS DATA ======== -->
<div class="header">
<div class="subTitle">org.apache.tomcat.jdbc.pool</div>
<h2 title="Class FairBlockingQueue.ItemFuture" class="title">Class FairBlockingQueue.ItemFuture&lt;T&gt;</h2>
</div>
<div class="contentContainer">
<ul class="inheritance">
<li>java.lang.Object</li>
<li>
<ul class="inheritance">
<li>org.apache.tomcat.jdbc.pool.FairBlockingQueue.ItemFuture&lt;T&gt;</li>
</ul>
</li>
</ul>
<div class="description">
<ul class="blockList">
<li class="blockList">
<dl>
<dt>All Implemented Interfaces:</dt>
<dd>java.util.concurrent.Future&lt;T&gt;</dd>
</dl>
<dl>
<dt>Enclosing class:</dt>
<dd><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.html" title="class in org.apache.tomcat.jdbc.pool">FairBlockingQueue</a>&lt;<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.html" title="type parameter in FairBlockingQueue">E</a>&gt;</dd>
</dl>
<hr>
<br>
<pre>protected class <span class="strong">FairBlockingQueue.ItemFuture&lt;T&gt;</span>
extends java.lang.Object
imp/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.log4j;

import org.apache.log4j.helpers.OptionConverter;
import org.apache.log4j.helpers.PatternConverter;
import org.apache.log4j.pattern.BridgePatternConverter;
import org.apache.log4j.spi.LoggingEvent;


// Contributors:   Nelson Minar <nelson@monkey.org>
//                 Anders Kristensen <akristensen@dynamicsoft.com>

/**
 * This class is an enhanced version of org.apache.log4j.PatternLayout
 * which was originally developed as part of the abandoned log4j 1.3
 * effort and has been available in the extras companion.
 * This pattern layout should be used in preference to
 * org.apache.log4j.PatternLayout except when compatibility
 * where PatternLayout has been extended either through subclassing
 * or alternative pattern parsers.
 *
 *
  * <p>A flexible layout configurable with pattern string. The goal of this class
  * is to {@link #format format} a {@link LoggingEvent} and return the results
  * in a {@link StringBuffer}. The format of the result depends on the
  * <em>conversion pattern</em>.
  * <p>
  *
  * <p>The conversion pattern is closely related to the conversion
  * pattern of the printf function in C. A conversion pattern is
  * composed of literal text and format control expressions called
  * <em>conversion specifiers</em>.
  *
  * <p><i>Note that you are free to insert any literal text within the
  * conversion pattern.</i>
  * </p>

   <p>Each conversion specifier starts with a percent sign (%) and is
   followed by optional <em>format modifiers</em> and a <em>conversion
   character</em>. The conversion character specifies the type of
   data, e.g. category, priority, date, thread name. The format
   modifiers control such things as field width, padding, left and
   right justification. The following is a simple example.

   <p>Let the conversion pattern be <b>"%-5p [%t]: %m%n"</b> and assume
   that the log4j environment was set to use a EnhancedPatternLayout. Then the
   statements
   <pre>
   Category root = Category.getRoot();
   root.debug("Message 1");
   root.warn("Message 2");
   </pre>
   would yield the output
   <pre>
   DEBUG [main]: Message 1
   WARN  [main]: Message 2
   </pre>

   <p>Note that there is no explicit separator between text and
   conversion specifiers. The pattern parser knows when it has reached
   the end of a conversion specifier when it reads a conversion
   character. In the example above the conversion specifier
   <b>%-5p</b> means the priority of the logging event should be left
   justified to a width of five characters.

   The recognized conversion characters are

   <p>
   <table border="1" CELLPADDING="8">
   <th>Conversion Character</th>
   <th>Effect</th>

   <tr>
     <td align=center><b>c</b></td>

     <td>Used to output the category of the logging event. The
     category conversion specifier can be optionally followed by
     NameAbbreviator pattern.

     <p>For example, for the category name "alpha.beta.gamma" the pattern
     <b>%c{2}</b> will output the last two elements ("beta.gamma"),
     <b>%c{-2}</b> will remove two elements leaving "gamma",
     <b>%c{1.}</b> will output "a.b.gamma".

     </td>
   </tr>

   <tr>
     <td align=center><b>C</b></td>

     <td>Used to output the fully qualified class name of the caller
     issuing thlements java.util.concurrent.Future&lt;T&gt;</pre>
</li>
</ul>
</div>
<div class="summary">
<ul class="blockList">
<li class="blockList">
<!-- =========== FIELD SUMMARY =========== -->
<ul class="blockList">
<li class="blockList"><a name="field_summary">
<!--   -->
</a>
<h3>Field Summary</h3>
<table class="overviewSummary" border="0" cellpadding="3" cellspacing="0" summary="Field Summary table, listing fields, and an explanation">
<caption><span>Fields</span><span class="tabEnd">&nbsp;</span></caption>
<tr>
<th class="colFirst" scope="col">Modifier and Type</th>
<th class="colLast" scope="col">Field and Description</th>
</tr>
<tr class="altColor">
<td class="colFirst"><code>protected boolean</code></td>
<td class="colLast"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#canceled">canceled</a></strong></code>&nbsp;</td>
</tr>
<tr class="rowColor">
<td class="colFirst"><code>protected <a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a></code></td>
<td class="colLast"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#item">item</a></strong></code>&nbsp;</td>
</tr>
<tr class="altColor">
<td class="colFirst"><code>protected <a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ExchangeCountDownLatch.html" title="class in org.apache.tomcat.jdbc.pool">FairBlockingQueue.ExchangeCountDownLatch</a>&lt;<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a>&gt;</code></td>
<td class="colLast"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#latch">latch</a></strong></code>&nbsp;</td>
</tr>
</table>
</li>
</ul>
<!-- ======== CONSTRUCTOR SUMMARY ======== -->
<ul class="blockList">
<li class="blockList"><a name="constructor_summary">
<!--   -->
</a>
<h3>Constructor Summary</h3>
<table class="overviewSummary" border="0" cellpadding="3" cellspacing="0" summary="Constructor Summary table, listing constructors, and an explanation">
<caption><span>Constructors</span><span class="tabEnd">&nbsp;</span></caption>
<tr>
<th class="colOne" scope="col">Constructor and Description</th>
</tr>
<tr class="altColor">
<td class="colOne"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#FairBlockingQueue.ItemFuture(org.apache.tomcat.jdbc.pool.FairBlockingQueue.ExchangeCountDownLatch)">FairBlockingQueue.ItemFuture</a></strong>(<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ExchangeCountDownLatch.html" title="class in org.apache.tomcat.jdbc.pool">FairBlockingQueue.ExchangeCountDownLatch</a>&lt;<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a>&gt;&nbsp;latch)</code>&nbsp;</td>
</tr>
<tr class="rowColor">
<td class="colOne"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#FairBlockingQueue.ItemFuture(T)">FairBlockingQueue.ItemFuture</a></strong>(<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a>&nbsp;item)</code>&nbsp;</td>
</tr>
</table>
</li>
</ul>
<!-- ========== METHOD SUMMARY =========== -->
<ul class="blockList">
<li class="blockList"><a name="method_summary">
<!--   -->
</a>
<h3>Method Summary</h3>
<table class="overviewSummary" border="0" cellpadding="3" cellspacing="0" summary="Method Summary table, listing methods, and an explanation">
<caption><span>Methods</span><span class="tabEnd">&nbsp;</span></caption>
<tr>
<th class="colFirst" scope="col">Modifier and Type</th>
<th class="colLast" scope="col">Method and Description</th>
</tr>
<tr class="altColor">
<td class="colFirst"><code>boolean</code></td>
<td class="colLast"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/poole logging request. This conversion specifier
     can be optionally followed by <em>precision specifier</em>, that
     is a decimal constant in brackets.

     <td>Used to output the category of the logging event. The
     category conversion specifier can be optionally followed by
     NameAbbreviator pattern.

     <p>For example, for the category name "alpha.beta.gamma" the pattern
     <b>%c{2}</b> will output the last two elements ("beta.gamma"),
     <b>%c{-2}</b> will remove two elements leaving "gamma",
     <b>%c{1.}</b> will output "a.b.gamma".

     <p><b>WARNING</b> Generating the caller class information is
     slow. Thus, its use should be avoided unless execution speed is
     not an issue.

     </td>
     </tr>

   <tr> <td align=center><b>d</b></td> <td>Used to output the date of
         the logging event. The date conversion specifier may be
         followed by a set of braces containing a
         date and time pattern strings {@link java.text.SimpleDateFormat},
         <em>ABSOLUTE</em>, <em>DATE</em> or <em>ISO8601</em>
          and a set of braces containing a time zone id per 
          {@link java.util.TimeZone#getTimeZone(String)}.           
          For example, <b>%d{HH:mm:ss,SSS}</b>,
         <b>%d{dd&nbsp;MMM&nbsp;yyyy&nbsp;HH:mm:ss,SSS}</b>,
         <b>%d{DATE}</b> or <b>%d{HH:mm:ss}{GMT+0}</b>. If no date format specifier is given then
         ISO8601 format is assumed.  
     </td>
   </tr>

   <tr>
   <td align=center><b>F</b></td>

   <td>Used to output the file name where the logging request was
   issued.

   <p><b>WARNING</b> Generating caller location information is
   extremely slow and should be avoided unless execution speed
   is not an issue.

   </tr>

   <tr>
   <td align=center><b>l</b></td>

     <td>Used to output location information of the caller which generated
     the logging event.

     <p>The location information depends on the JVM implementation but
     usually consists of the fully qualified name of the calling
     method followed by the callers source the file name and line
     number between parentheses.

     <p>The location information can be very useful. However, its
     generation is <em>extremely</em> slow and should be avoided
     unless execution speed is not an issue.

     </td>
   </tr>

   <tr>
   <td align=center><b>L</b></td>

   <td>Used to output the line number from where the logging request
   was issued.

   <p><b>WARNING</b> Generating caller location information is
   extremely slow and should be avoided unless execution speed
   is not an issue.

   </tr>


   <tr>
     <td align=center><b>m</b></td>
     <td>Used to output the application supplied message associated with
     the logging event.</td>
   </tr>

   <tr>
   <td align=center><b>M</b></td>

   <td>Used to output the method name where the logging request was
   issued.

   <p><b>WARNING</b> Generating caller location information is
   extremely slow and should be avoided unless execution speed
   is not an issue.

   </tr>

   <tr>
     <td align=center><b>n</b></td>

     <td>Outputs the platform dependent line separator character or
     characters.

     <p>This conversion character offers practically the same
     performance as using non-portable line separator strings such as
     "\n", or "\r\n". Thus, it is the preferred way of specifying a
     line separator.


   </tr>

   <tr>
     <td align=center><b>p</b></td>
     <td>Used to output the priority of the logging event.</td>
   </tr>

   <tr>

     <td align=center><b>r</b></td>

     <td>Used to output the number of milliseconds elapsed since the construction 
     of the layout until the creation of the logging event.</td>
   </tr>


   <tr>
     <td align=center><b>t</b></td>

     <td>Used to output the name of the thread that generated the
     logging event.</td>

   </tr>

   <tr>

     <td align=center><b>x</b></td>

     <td>Used to output the NDC (nested diagnostic context) associated
     with the thread that generated the logging event.
     </td>
   </tr>


   <tr>
     <td align=center><b/FairBlockingQueue.ItemFuture.html#cancel(boolean)">cancel</a></strong>(boolean&nbsp;mayInterruptIfRunning)</code>&nbsp;</td>
</tr>
<tr class="rowColor">
<td class="colFirst"><code><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a></code></td>
<td class="colLast"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#get()">get</a></strong>()</code>&nbsp;</td>
</tr>
<tr class="altColor">
<td class="colFirst"><code><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a></code></td>
<td class="colLast"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#get(long,%20java.util.concurrent.TimeUnit)">get</a></strong>(long&nbsp;timeout,
   java.util.concurrent.TimeUnit&nbsp;unit)</code>&nbsp;</td>
</tr>
<tr class="rowColor">
<td class="colFirst"><code>boolean</code></td>
<td class="colLast"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#isCancelled()">isCancelled</a></strong>()</code>&nbsp;</td>
</tr>
<tr class="altColor">
<td class="colFirst"><code>boolean</code></td>
<td class="colLast"><code><strong><a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html#isDone()">isDone</a></strong>()</code>&nbsp;</td>
</tr>
</table>
<ul class="blockList">
<li class="blockList"><a name="methods_inherited_from_class_java.lang.Object">
<!--   -->
</a>
<h3>Methods inherited from class&nbsp;java.lang.Object</h3>
<code>clone, equals, finalize, getClass, hashCode, notify, notifyAll, toString, wait, wait, wait</code></li>
</ul>
</li>
</ul>
</li>
</ul>
</div>
<div class="details">
<ul class="blockList">
<li class="blockList">
<!-- ============ FIELD DETAIL =========== -->
<ul class="blockList">
<li class="blockList"><a name="field_detail">
<!--   -->
</a>
<h3>Field Detail</h3>
<a name="item">
<!--   -->
</a>
<ul class="blockList">
<li class="blockList">
<h4>item</h4>
<pre>protected volatile&nbsp;<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a> item</pre>
</li>
</ul>
<a name="latch">
<!--   -->
</a>
<ul class="blockList">
<li class="blockList">
<h4>latch</h4>
<pre>protected volatile&nbsp;<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ExchangeCountDownLatch.html" title="class in org.apache.tomcat.jdbc.pool">FairBlockingQueue.ExchangeCountDownLatch</a>&lt;<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a>&gt; latch</pre>
</li>
</ul>
<a name="canceled">
<!--   -->
</a>
<ul class="blockListLast">
<li class="blockList">
<h4>canceled</h4>
<pre>protected volatile&nbsp;boolean canceled</pre>
</li>
</ul>
</li>
</ul>
<!-- ========= CONSTRUCTOR DETAIL ======== -->
<ul class="blockList">
<li class="blockList"><a name="constructor_detail">
<!--   -->
</a>
<h3>Constructor Detail</h3>
<a name="FairBlockingQueue.ItemFuture(java.lang.Object)">
<!--   -->
</a><a name="FairBlockingQueue.ItemFuture(T)">
<!--   -->
</a>
<ul class="blockList">
<li class="blockList">
<h4>FairBlockingQueue.ItemFuture</h4>
<pre>public&nbsp;FairBlockingQueue.ItemFuture(<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ItemFuture.html" title="type parameter in FairBlockingQueue.ItemFuture">T</a>&nbsp;item)</pre>
</li>
</ul>
<a name="FairBlockingQueue.ItemFuture(org.apache.tomcat.jdbc.pool.FairBlockingQueue.ExchangeCountDownLatch)">
<!--   -->
</a>
<ul class="blockListLast">
<li class="blockList">
<h4>FairBlockingQueue.ItemFuture</h4>
<pre>public&nbsp;FairBlockingQueue.ItemFuture(<a href="../../../../../org/apache/tomcat/jdbc/pool/FairBlockingQueue.ExchangeCountDownLatch.html" title="class in org.apache.tomcat.jdbc.pool">FairBlockingQueue.ExchangeCountDownLatch</a>&lt;<a href="../../../../../org/apach